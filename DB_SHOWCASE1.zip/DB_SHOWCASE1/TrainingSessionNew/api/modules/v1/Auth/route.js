var express = require('express');
var middleware = require('../../../middleware/headerValidator');
var common = require('../../../config/common');
var auth_model = require('./auth_model');
var router = express.Router();

/*
 * Signup api for User
 * 29-08-2022
 */
router.post("/signup", function (req, res) {

    // request method decryption
    console.log(req.body)
    middleware.decryption(req, function (request) {
        console.log(request)
        var rules = {
            name: 'required',
            //username: 'required',
            email: 'required',
            password: '',
            device_type: 'required|in:A,I',
            device_token: 'required',
            dob: '',
            //address: '',
            latitude: '',
            longitude: '',
            social_id:'',
        }
        
        const messages = {
            'required': req.language.required,
            'in': req.language.in,
        }

        // checks all validation rules defined above and if error send back response
        if (middleware.checkValidationRules(request, res, rules, messages, {})) {
            auth_model.signUpUsers(request, function (responsecode, responsemsg, responsedata) {
                middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
            });
        }
    });
});

/*
 * Login api for User
 * 29-08-2022
 */
router.post("/login", function (req, res) {

    middleware.decryption(req, function (request) {

        var request = request
        var rules = {
            device_token: 'required',
            device_type: 'required|in:A,I',
            email: 'required',
            password: '',
            social_id:'',
            login_type:'required|in:S,F,G',
        }

        const messages = {
            'required': req.language.required,
            'in': req.language.in,
        }

        // checks all validation rules defined above and if error send back response
        if (middleware.checkValidationRules(request, res, rules, messages, {})) {
            auth_model.checkLogin(request, function (responsecode, responsemsg, responsedata) {
                middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
            });
        }
    });
});



/*
 * Find Place
 * 29-08-2022
 */
router.post("/find_place", function (req, res) {

    middleware.decryption(req, function (request) {

        var request = request
        var rules = {   
            latitude: 'required',
            longitude: 'required',
            search_text:'',
        }
        const messages = {
            'required': req.language.required,
        }

        // checks all validation rules defined above and if error send back response
        if (middleware.checkValidationRules(request, res, rules, messages, {})) {
            auth_model.find_place(request, function (responsecode, responsemsg, responsedata) {
                middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
            });
        }
    });
});

/* 
 * API to get users details
 * 12-04-2022
 */
/*  router.post("/userdetails", function (req, res) {
    middleware.decryption(req, function (request) {

        var rules = {
            page: ''
        }
        const messages = {}

        // checks all validation rules defined above and if error send back response
        if (middleware.checkValidationRules(request, res, rules, messages, {})) {
            auth_model.userdetails(req.user_id, function (userProfile) {
                if (userProfile != null) {
                    request.user_id = req.user_id;
                    require('../Social/social_model').userspostList(req.user_id, request, function (responsecode, responsemsg, responsedata) {
                        userProfile.postlist = (responsedata != null) ? responsedata : [];

                        middleware.sendresponse(req, res, 200, '1', {
                            keyword: 'rest_keywords_user_data_successfound',
                            components: {}
                        }, userProfile);
                    });
                } else {
                    middleware.sendresponse(req, res, 200, '0', {
                        keyword: 'rest_keywords_userdetailsnot_found',
                        components: {}
                    }, null);
                }
            });
        }
    });
});
  */


/* 
 * API to get users details
 * 23-08-2022
 */

router.get("/userdetails", function (req, res) {
        // checks all validation rules defined above and if error send back response
        
            auth_model.userdetails(req.user_id, function (userProfile) {
                if (userProfile != null) {    

             auth_model.get_pins(req.user_id, function (pinDetails) {
                console.log()
               userProfile.pin_list=pinDetails;
                       middleware.sendresponse(req, res, 200, '1', {
                            keyword: 'rest_keywords_user_data_successfound',
                            components: {}
                        }, userProfile);
                    })                 
                } else {
                    middleware.sendresponse(req, res, 200, '0', {
                        keyword: 'rest_keywords_userdetailsnot_found',
                        components: {}
                    }, null);
                }
            });
});




/*
 * Forgot password API for users
 * 12-04-2022
 */
router.post("/forgotpassword", function (req, res) {

    middleware.decryption(req, function (request) {

        var request = request
        var rules = {
            email: 'required|email'
        }

        const messages = {
            'required': req.language.required,
            'email': req.language.email,
        }

        // checks all validation rules defined above and if error send back response
        if (middleware.checkValidationRules(request, res, rules, messages, {})) {
            auth_model.forgotPassword(request, function (responsecode, responsemsg, responsedata) {
                middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
            });
        }
    });
});

/*
 * Change password API for users
 * 12-04-2022
 */
router.post("/changepassword", function (req, res) {

    middleware.decryption(req, function (request) {

        var request = request
        var rules = {
            old_password: 'required',
            new_password: 'required',
        }

        const messages = {
            'required': req.language.required
        }

        // checks all validation rules defined above and if error send back response
        if (middleware.checkValidationRules(request, res, rules, messages, {})) {
            auth_model.changePassword(req.user_id, request, function (responsecode, responsemsg, responsedata) {
                middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
            });
        }
    });
});

/**
 * Api for update device type and token
 * 12-04-2022
 */
 router.post("/updatedeviceinfo", function (req, res) {

    middleware.decryption(req, function (request) {

        var rules = {
            device_type: 'required|in:A,I',
            device_token: 'required'
        }

        const messages = {
            'required': req.language.required,
            'in': req.language.in
        }

        // checks all validation rules defined above and if error send back response
        if (middleware.checkValidationRules(request, res, rules, messages, {})) {
            common.checkUpdateDeviceInfo(req.user_id, req.user_type, request, function () {
                middleware.sendresponse(req, res, 200, '1', {
                    keyword: 'rest_keywords_userdevice_infosuccess',
                    components: {}
                }, null);
            });
        }
    });
}); 

/**
 * Api for update users location
 * 12-04-2022
 */
 router.post("/updatelatlng", function (req, res) {

    middleware.decryption(req, function (request) {

        var rules = {
            latitude: 'required',
            longitude: 'required'
        }
        const messages = {
            'required': req.language.required,
        }

        if (middleware.checkValidationRules(request, res, rules, messages, {})) {
            var updparams = {
                latitude: request.latitude,
                longitude: request.longitude
            };
            auth_model.updateCustomer(req.user_id, updparams, function (userprofile) {
                if (userprofile == null) {
                    middleware.sendresponse(req, res, 200, '0', {
                        keyword: 'rest_keywords_something_went_wrong',
                        components: {}
                    }, null);
                } else {
                    middleware.sendresponse(req, res, 200, '1', {
                        keyword: 'rest_keywords_locationupdate_success',
                        components: {}
                    }, userprofile);
                }
            });
        }
    });
}); 

/**
 * Api for logout user
 * 12-04-2022
 */
router.post("/logout", function (req, res) {

    var updusers = {
        is_online: "0"
    };
    auth_model.updateCustomer(req.user_id, updusers, function (userprofile, error) {
        if (userprofile != null) {
            var deviceparam = {
                token: "",
                device_token: ""
            };
            common.updateDeviceInfo(req.user_id, 'User', deviceparam, function (respond) {
                middleware.sendresponse(req, res, 200, '1', {
                    keyword: 'rest_keywords_userlogout_success',
                    components: {}
                }, null);
            });
        } else {
            middleware.sendresponse(req, res, 200, '0', {
                keyword: 'rest_keywords_something_went_wrong',
                components: {}
            }, null);
        }
    });
});


//Add Place api

router.post("/addplace", function (req, res) {

    console.log(req.body)
    middleware.decryption(req, function (request) {
        console.log(request)
        var rules = {
            location: 'required',
            latitude: 'required',
            longitude: 'required',
            about: '',
        }
        
        const messages = {
            'required': req.language.required,
            'in': req.language.in,
        }

        if (middleware.checkValidationRules(request, res, rules, messages, {})) {
            auth_model.addplace(request, function (responsecode, responsemsg, responsedata) {
                middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
            });
        }
    });
});




// API to get place details
router.get("/placedetails", function (req, res) {
    middleware.decryption(req, function (request) {
        auth_model.placedetails(request, function (reviewProfile) {
            if (reviewProfile != null) {
                auth_model.get_image(request.place_id, function (revDetails) {
                    reviewProfile.pin_list = revDetails;
                    middleware.sendresponse(req, res, 200, '1', {
                        keyword: 'rest_keywords_user_data_successfound',
                        components: {}
                    }, reviewProfile);
        });

            } else {
                middleware.sendresponse(req, res, 200, '0', {
                    keyword: 'rest_keywords_userdetailsnot_found',
                    components: {}
                }, null);
            }
        });
    });
});



//Add Review Api
router.post('/addreview', function(req, res){
    middleware.decryption(req, function(request){

        var reviw = {
            place_id: 'required',
            review: 'required',
            rating :'required'
            
        }

        const message = {
            'required' : req.language.required,
            'in': req.language.required,
        }

        if(middleware.checkValidationRules(request, res, reviw, message, {})) {
            auth_model.add_review(request, function(responsecode, responsemsg, responsedata){
                middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata)
            })
        }
    })
});





/*
 * Contact us API for all users 
 * 12-04-2022
 */
router.post("/contactus", function (req, res) {

    middleware.decryption(req, function (request) {

        var rules = {
            full_name: 'required',
            email: 'required|email',
            subject: 'required',
            description: '',
            user_id: '',
        }

        const messages = {
            'required': req.language.required,
            'email': req.language.email,
        }

        // checks all validation rules defined above and if error send back response
        if (middleware.checkValidationRules(request, res, rules, messages, {})) {
            auth_model.saveContactUs(request, function (responsecode, responsemsg, responsedata) {
                middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
            });
        }
    });
});

/*
 * API for edit profile for customers
 * 26-08-2022
 */
router.post("/editprofile", function (req, res) {

    middleware.decryption(req, function (request) {
        var rules = {
            name: 'required',
            email:'',
            profile_image: '',
            about : '',
        }
        const messages = {
            'required': req.language.required
        }
        // checks all validation rules defined above and if error send back response
        if (middleware.checkValidationRules(request, res, rules, messages, {})) {
            auth_model.editProfile(req.user_id, request, function (responsecode, responsemsg, responsedata) {
                middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
            });
        }
    });
});

module.exports = router;