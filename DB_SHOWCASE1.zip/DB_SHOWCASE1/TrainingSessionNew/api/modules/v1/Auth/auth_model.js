var con = require('../../../config/database');
var GLOBALS = require('../../../config/constants');
var common = require('../../../config/common');
var cryptoLib = require('cryptlib');
var asyncLoop = require('node-async-loop');
var moment = require('moment');
var shaKey = cryptoLib.getHashSha256(GLOBALS.KEY, 32);
var emailTemplate = require('../../../config/template');

var Auth = {

    /**
     * Function to get details of any users
     * 12-04-2022
     * @param {Login User ID} user_id 
     * @param {Function} callback
     */
    userdetails: function (user_id, callback) {

        con.query("SELECT u.*,concat('" + GLOBALS.S3_BUCKET_ROOT + GLOBALS.USER_IMAGE + "','',u.profile_image) as profile_image,IFNULL(ut.device_token,'') as device_token,IFNULL(ut.device_type,'') as device_type,IFNULL(ut.token,'') as token FROM tbl_user u LEFT JOIN tbl_user_device as ut ON u.id = ut.user_id WHERE u.id = '" + user_id + "' AND u.is_deleted='0' GROUP BY u.id", function (err, result, fields) {
            console.log("Error of Users", err);
            if (!err && result.length > 0) {
                callback(result[0]);
            } else {
                callback(null);
            }
        });
    },

   // Function to get details of any review
    placedetails: function (req, callback) {
        con.query("SELECT tbl_place.location, tbl_place.latitude, tbl_place.longitude, tbl_place.about, tbl_place.total_review, avg(tbl_place.avg_rating), tbl_place_image.image FROM tbl_place right JOIN tbl_place_image ON tbl_place_image.place_id = tbl_place.id WHERE tbl_place.id = " + req.place_id + " and tbl_place.is_active=1",
            function (err, result, fields) {
                console.log("Error of place", err);
                if (!err && result.length > 0) {
                    callback(result[0]);
                } else {
                    callback(null);
                }
            });
    },

    // All Detail of image
    get_image: function (place_id, callback) {
        con.query(`SELECT * FROM tbl_place_image WHERE place_id ='` + place_id + `'`, function (err, result, fields) {
            // console.log("Error of Users",err)
            if (!err && result.length > 0) {
                callback(result);
            } else {
                callback(null);
            }
        });
    },




    //Place Details
    /* place_details: function (id, callback) {
        con.query(` SELECT * FROM tbl_place 
                    WHERE id = '`+id+`'
        `, function (err, result, fields) {
            console.log("Error of Users", err);
            if (!err && result.length > 0) {
                console.log(result[0])
                callback(result[0]);
            } else {
                callback(null);
            }
        });
    },
 */


    //Get_pins function
    get_pins: function (user_id, callback) {

        con.query(` SELECT * FROM tbl_place 
                    WHERE user_id = '`+user_id+`'
        `, function (err, result, fields) {
            console.log("Error of Users", err);
            if (!err && result.length > 0) {
                console.log(result)
                callback(result);
            } else {
                callback(null);
            }
        });
    },



    //get_place image function
  /*   get_place_image: function (user_id, callback) {

        con.query(` SELECT * FROM tbl_place_image 
                    WHERE user_id = '`+user_id+`'
        `, function (err, result, fields) {
            console.log("Error of Users", err);
            if (!err && result.length > 0) {
                console.log(result)
                callback(result);
            } else {
                callback(null);
            }
        });
    }, */

    /**
     * Function for check unique email and phone numbers for users
     * 12-04-2022
     * @param {Login User ID} user_id 
     * @param {Request Data} request 
     * @param {Function} callback 
     */
    checkUniqueFields: function (user_id, request, callback) {

        // Check in database for this email register
        Auth.checkUniqueEmail(user_id, request, function (emailcode, emailmsg, emailUnique) {
            if (emailUnique) {
                Auth.checkUniqueUsername(user_id, request, function (phonecode, phonemsg, phoneUnique) {
                    if (phoneUnique) {
                        callback(phonecode, phonemsg, phoneUnique);
                    } else {
                        callback(phonecode, phonemsg, phoneUnique);
                    }
                });
            } else {
                callback(emailcode, emailmsg, emailUnique);
            }
        });
    },

    /**
     * Function to check email uniqueness
     * 12-04-2022
     * @param {Login User ID} user_id 
     * @param {Request} request 
     * @param {Function} callback 
     */
    checkUniqueEmail: function (user_id, request, callback) {

        if (request.email != undefined && request.email != '') {

            if (user_id != undefined && user_id != '') {
                var uniqueEmail = "SELECT * FROM tbl_user WHERE email = '" + request.email + "' AND is_deleted='0' AND id != '" + user_id + "' ";
            } else {
                var uniqueEmail = "SELECT * FROM tbl_user WHERE email = '" + request.email + "' AND is_deleted='0' ";
            }
            con.query(uniqueEmail, function (error, result, fields) {
                if (!error && result[0] != undefined) {
                    callback('0', {
                        keyword: 'rest_keywords_duplicate_email',
                        components: {}
                    }, false);
                } else {
                    callback('1', "Success", true);
                }
            });

        } else {
            callback('1', "Success", true);
        }
    },

    /**
     * Function to check email uniqueness
     * 12-04-2022
     * @param {Login User ID} user_id 
     * @param {Request} request 
     * @param {Function} callback 
     */
     checkUniqueUsername: function (user_id, request, callback) {

        if (request.username != undefined && request.username != '') {

            if (user_id != undefined && user_id != '') {
                var uniqueUsername = "SELECT * FROM tbl_user WHERE username = '" + request.username + "' AND is_deleted='0' AND id != '" + user_id + "' ";
            } else {
                var uniqueUsername = "SELECT * FROM tbl_user WHERE username = '" + request.username + "' AND is_deleted='0' ";
            }
            con.query(uniqueUsername, function (error, result, fields) {
                if (!error && result[0] != undefined) {
                    callback('0', {
                        keyword: 'rest_keywords_duplicate_username',
                        components: {}
                    }, false);
                } else {
                    callback('1', "Success", true);
                }
            });

        } else {
            callback('1', "Success", true);
        }
    },

    /**
     * Function to update users details
     * 12-04-2022
     * @param {Login User ID} user_id 
     * @param {Update Parameters} upd_params 
     * @param {Function} callback 
     */
    updateCustomer: function (user_id, upd_params, callback) {
        con.query("UPDATE tbl_user SET ? WHERE id = ? ", [upd_params, user_id], function (err, result, fields) {
            if (!err) {
                Auth.userdetails(user_id, function (response, err) {
                    callback(response);
                });
            } else {
                callback(null, err);
            }
        });
    },

    /**
     * Function to signup for users
     * @param {request} request 
     * @param {Function} callback 
     */
    signUpUsers: function (request, callback) {
        Auth.checkUniqueFields('', request, function (uniquecode, uniquemsg, isUnique) {
            if (isUnique) {
                
                var customer = {
                    social_id:(request.social_id != undefined && request.social_id != '')?request.social_id:'',
                    //username: request.username,
                    name: request.name,
                    email: (request.email != undefined && request.email != "") ? request.email : '',
                    //address: (request.address != undefined && request.address != "") ? request.address : '',
                    //latitude: (request.latitude != undefined && request.latitude != "") ? request.latitude : '',
                    //longitude: (request.longitude != undefined && request.longitude != "") ? request.longitude : '',
                    is_active: '1',
                    is_online: '1',
                    profile_image: 'default.png',
                    password:(request.password != undefined && request.password != '')?cryptoLib.encrypt(request.password,shaKey,process.env.ENC_IV):'',
                };

                con.query('INSERT INTO tbl_user SET ?', customer, function (err, result, fields) {
                    if (!err) {
                        
                        common.checkUpdateDeviceInfo(result.insertId, "Customer", request, function () {
                        
                            Auth.userdetails(result.insertId, function (userprofile, err) {
                                
                                common.generateSessionCode(result.insertId, "Customer", function (Token) {
                        
                                    userprofile.token = Token;
                                    callback('1', {
                                        keyword: 'rest_keywords_user_signup_success',
                                        components: {}
                                    }, userprofile);
                                });
                            });
                        });
                    } else {
                        console.log(err)
                        callback('0', {
                            keyword: 'rest_keywords_user_signup_failed',
                            components: {}
                        }, null);
                    }
                });

            } else {
                callback(uniquecode, uniquemsg, null);
            }
        });
    },


//Add place image for single image
addplaceimage:function(Params,callback){
    con.query(`INSERT INTO tbl_place_image SET ?`,Params,function(err,result,fields){
        console.log(err)
        callback(result.insertId);
    });
},




//Add place function
addplace: function (request, callback) {
        Auth.checkUniqueFields('', request, function (uniquecode, uniquemsg, isUnique) {
            if (isUnique) {
                
                var place = {
                    user_id:request.user_id,
                    location: request.location,
                    latitude: request.latitude,
                    longitude: request.longitude,
                    about: request.about,
                    //avg_rating:request.avg_rating,
                    //totalreview:request.totalreview
                };

                //console.log(place)
                con.query('INSERT INTO tbl_place SET ?',place, function(err,result,fields){
                    if(!err){
                        var place_id=result.insertId
                        if(place_id !=0){
                            Auth.addImage(request,place_id,function(){
                                callback('1', {
                                    keyword: 'rest_keywords_location_add_success',
                                    components: {}
                                }, null);

                            })
                        }   
                            // Single image upload
                            // var place_id=result.insertId
                            // var params = {
                            //     image: request.image,
                            //     place_id: place_id,
                            // };
                         /*    Auth.addplaceimage(params, function () {
                                callback('1', {
                                    keyword: 'rest_keywords_location_add_success',
                                    components: {}
                                }, null);
                        }); */
                    }else {
                        console.log(err)
                        callback('0', {
                            keyword: 'rest_keywords_location_add_failed',
                            components: {}
                        }, null);
                    }
                })
            } else {
                callback(uniquecode, uniquemsg, null);
            };
        });
    },

               
    /**
     * Function to check login details of users
     * @param {request} request 
     * @param {Function} callback 
     */
    checkLogin: function (request, callback) {
  
    
        //chek user details via Email    
        if(request.social_id != undefined && request.login_type  != 'S'){         
            var whereCondition = "social_id = '"+request.social_id+"' AND login_type = '"+request.login_type+"'";
        }else{
        var whereCondition = " email='" + request.email + "' ";
        }
        con.query("SELECT * FROM tbl_user where " + whereCondition + " AND is_deleted='0' ", function (err, result, fields) {

            if (!err ) {

                if(result[0] != undefined){

                console.log(result)

                Auth.userdetails(result[0].id, function (userprofile) {

                    if(request.social_id != undefined && request.login_type != 'S'){
                        var flag = 1;
                    }//end if 
                    else{
                    var password = cryptoLib.decrypt(result[0].password, shaKey, GLOBALS.IV);
                    if(password === request.password){
                        var flag = 1;
                    }else{
                        var flag = 0;
                    }
                    }
                   if(flag == 1){
                        var updparams = {
                            is_online: "1",
                            last_login: require('node-datetime').create().format('Y-m-d H:M:S'),
                            //latitude: (request.latitude != undefined) ? request.latitude : '',
                            //longitude: (request.longitude != undefined) ? request.longitude : '',
                        }
                        // update device information of user
                        common.checkUpdateDeviceInfo(result[0].id, "Customer", request, function () {
                            Auth.updateCustomer(result[0].id, updparams, function (userprofile, error) {
                                common.generateSessionCode(result[0].id, "Customer", function (token) {
                                    userprofile.token = token;
                                    callback('1', {
                                        keyword: 'rest_keywords_user_login_success',
                                        components: {}
                                    }, userprofile);
                                });
                            });
                        });
                    }else{
                        callback('0', {
                            keyword: 'rest_keywords_inactive_accountby_admin',
                            components: {}
                        }, null);

                    }
                });
            }else{
                if(request.social_id != undefined && request.login_type != 'S'){
                    //chek email exitsts or not 
                    callback('11', {
                        keyword: 'text_user_login_new',
                        components: {}
                    }, null);
                    
                }else{
                    callback('0', {
                        keyword: 'text_user_login_fail',
                        components: {}
                    }, null);
                }

            }
            } else {
                callback('0', {
                    keyword: 'rest_keywords_invalid_email',
                    components: {}
                }, null);
            }
        });
    },

    /**
     * Function to send forgot password links
     * @param {request} request 
     * @param {Function} callback 
     */
    forgotPassword: function (request, callback) {

        con.query("SELECT * FROM tbl_user where email='" + request.email + "' AND is_deleted='0' ", function (err, result, fields) {
            if (!err & result[0] != undefined) {

                var updparams = {
                    forgotpassword_token: GLOBALS.APP_NAME + result[0].id,
                    forgotpassword_date: require('node-datetime').create().format('Y-m-d H:M:S')
                }
                Auth.updateCustomer(result[0].id, updparams, function (isupdated) {

                    result[0].encoded_user_id = Buffer.from(result[0].id.toString()).toString('base64');
                    emailTemplate.forgot_password(result[0], function (forgotTemplate) {
                        common.send_email("Forgot Password", request.email, forgotTemplate, function (isSend) {
                            if (isSend) {
                                callback('1', {
                                    keyword: 'rest_keywords_user_forgot_password_success',
                                    components: {}
                                }, result[0]);
                            } else {
                                callback('0', {
                                    keyword: 'rest_keywords_user_forgot_password_failed',
                                    components: {}
                                }, result[0]);
                            }
                        });
                    });
                });
            } else {
                callback('0', {
                    keyword: 'rest_keywords_user_doesnot_exist',
                    components: {}
                }, null);
            }
        });
    },

    /**
     * Function to change the password of users
     * @param {user id} user_id 
     * @param {request} request 
     * @param {Function} callback 
     */
    changePassword: function (user_id, request, callback) {
        Auth.userdetails(user_id, function (userprofile) {
            if (userprofile != null) {
                var currentpassword = cryptoLib.decrypt(userprofile.password, shaKey, GLOBALS.IV);
                if (currentpassword != request.old_password) {
                    callback('0', {
                        keyword: 'rest_keywords_user_old_password_incorrect',
                        components: {}
                    }, null);
                } else if (currentpassword == request.new_password) {
                    callback('0', {
                        keyword: 'rest_keywords_user_newold_password_similar',
                        components: {}
                    }, null);
                } else {
                    var password = cryptoLib.encrypt(request.new_password, shaKey, GLOBALS.IV);
                    var updparams = {
                        password: password
                    };
                    Auth.updateCustomer(user_id, updparams, function (userprofile) {
                        if (userprofile == null) {
                            callback('0', {
                                keyword: 'rest_keywords_something_went_wrong',
                                components: {}
                            }, null);
                        } else {
                            callback('1', {
                                keyword: 'rest_keywords_user_change_password_success',
                                components: {}
                            }, userprofile);
                        }
                    });
                }
            } else {
                callback('0', {
                    keyword: 'rest_keywords_userdetailsnot_found',
                    components: {}
                }, null);
            }
        });
    },

    /**
     * Function to save contact us request of all users
     * @param {request} request 
     * @param {Function} callback 
     */
     saveContactUs: function (request,callback) {
        var contactparams = {
            user_id : (request.user_id != undefined) ? request.user_id : '',
            full_name : request.full_name,
            subject : request.subject,
            email : request.email,
            description : (request.description != undefined) ? request.description : '',
        }
        con.query('INSERT INTO tbl_contactus SET ?', contactparams, function (err, result, fields) {
            if (!err) {

                request.encoded_user_id = (request.user_id != undefined) ? Buffer.from(request.user_id.toString()).toString('base64'): 0;
                emailTemplate.contactus(request, function(contactTemplate) {
                    common.send_email("Contact Us", request.email, contactTemplate, function(isSend) {
                        callback('1', {
                            keyword: 'rest_keywords_contactus_success',
                            components: {}
                        }, null);
                    });
                });
            } else {
                callback('0', {
                    keyword: 'rest_keywords_something_went_wrong',
                    components: {}
                }, null);
            }
        });
    }, 
    
    /**
     * Function to update users profile details
     * @param {user id} user_id 
     * @param {request} request 
     * @param {Function} callback 
     */
  /*   editProfile: function (user_id, request, callback) {
        Auth.userdetails(user_id, function (userprofile) {
            if (userprofile != null) {
                
                var updparams = {
                    full_name: request.full_name,
                    aboutme: (request.aboutme != undefined) ? request.aboutme : '',
                };
                
                if (request.profile_image != undefined && request.profile_image != "") {
                    updparams.profile_image = request.profile_image;
                }

                if (request.cover_image != undefined && request.cover_image != "") {
                    updparams.cover_image = request.cover_image;
                }

                Auth.updateCustomer(user_id, updparams, function (userprofile) {
                    if (userprofile == null) {
                        callback('0', {
                            keyword: 'rest_keywords_something_went_wrong',
                            components: {}
                        }, null);
                    } else {
                        callback('1', {
                            keyword: 'rest_keywords_profileupdate_success',
                            components: {}
                        }, userprofile);
                    }
                });

            } else {
                callback('0', {
                    keyword: 'rest_keywords_userdetailsnot_found',
                    components: {}
                }, null);
            }
        });
    },
 */
    //Sonali mam 25-08-2022 multiple image upload
    addImage: function(req,place_id,callback){

        console.log(place_id)

        try {
            var image_array = JSON.parse(req.images);
        } catch (e) {
            var image_array = req.images;
        }

        //console.log(image_array)

        var params_ques_ans  = [];

        for (var key in image_array) {
            params_ques_ans.push([place_id, image_array[key]['image']]);
        }

        
        var sql = "INSERT INTO tbl_place_image (`place_id`,`image` ) VALUES ?";
        con.query(sql, [params_ques_ans], function (err, result1, fields) {
          console.log(result1)
          console.log(err)
            callback(true);

        });
    },


    add_review: function(request, callback){
        var reviw = {
            user_id: request.user_id,
            place_id : request.place_id,
            rating: request.rating,
            review: request.review,
        }
        con.query(`INSERT INTO tbl_review SET ?`, reviw, function(err, result, fields){
            if(!err){
                callback('1', {
                    keyword: 'rest_keywords_review_add_success',
                    components: {}
                }, null);
            } else {
                callback('0', {
                    keyword: 'rest_keywords_review_add_failed',
                    components: {}
                }, null);
            }

        })
    },
  
       // Function to update users profile details
       editProfile: function (user_id, request, callback) {
        Auth.userdetails(user_id, function (userprofile) {
            if (userprofile != null) {

                var updparams = {
                    name: request.name,
                    about: (request.about != undefined) ? request.about : '',
                };

                if (request.profile_image != undefined && request.profile_image != "") {
                    updparams.profile_image = request.profile_image;
                }

                if (request.email != undefined && request.email != "") {
                    updparams.email = request.email;
                }

                Auth.updateCustomer(user_id, updparams, function (userprofile) {
                    if (userprofile == null) {
                        callback('0', {
                            keyword: 'rest_keywords_something_went_wrong',
                            components: {}
                        }, null);
                    } else {
                        callback('1', {
                            keyword: 'rest_keywords_profileupdate_success',
                            components: {}
                        }, userprofile);
                    }
                });

            } else {
                callback('0', {
                    keyword: 'rest_keywords_userdetailsnot_found',
                    components: {}
                }, null);
            }
        });
    },


    /*
    * Find Place
    * 29-08-2022
    */
    find_place: function (req,callback) {
         
         var where = '';
        if(req.search_text != undefined && req.search_text != ''){
            where = ` AND (p.name LIKE '%`+req.search_text+`%'  OR p.location LIKE '%`+req.search_text+`%')`;
        }

      var q = con.query(`SELECT p.*,(6371 * 2 *  ASIN(SQRT(POWER(SIN(('`+req.latitude+`' - p.latitude) * pi()/180 /2),(2) ) + COS('`+req.latitude+`' * pi() / 180) * COS(p.latitude * pi()/180) * POWER(SIN(('`+req.longitude+`' - p.longitude) * pi()/180 /2), (2) ) ))) as distance
      FROM tbl_place p 
      WHERE p.is_active = '1'
        `+where+`
        HAVING distance <=10`,
         function (err, result, fields) {
            console.log(q.sql)
            console.log("Error of Users", err);
            if (!err && result.length > 0) {
                callback('1', {
                    keyword: 'rest_keywords_review_add_failed',
                    components: {}
                }, result);
            } else {
                callback('0', {
                    keyword: 'rest_keywords_review_add_failed',
                    components: {}
                }, null);           
             }
        });
    },
}
    

module.exports = Auth;