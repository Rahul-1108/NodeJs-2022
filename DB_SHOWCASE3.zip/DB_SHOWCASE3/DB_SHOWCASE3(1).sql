-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 05, 2022 at 02:41 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `DB_SHOWCASE3`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_color`
--

CREATE TABLE `tbl_color` (
  `id` bigint(20) NOT NULL,
  `glass_details_id` bigint(20) NOT NULL,
  `color` varchar(50) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_color`
--

INSERT INTO `tbl_color` (`id`, `glass_details_id`, `color`, `is_active`, `created_at`, `updated_at`) VALUES
(4, 2, 'Brown', 1, '2022-09-03 10:33:21', '2022-09-03 10:33:21'),
(5, 2, 'White', 1, '2022-09-03 10:33:21', '2022-09-03 10:33:21'),
(6, 2, 'Black', 1, '2022-09-03 10:33:21', '2022-09-03 10:33:21'),
(7, 3, 'Black', 1, '2022-09-03 10:33:21', '2022-09-03 10:33:21'),
(8, 3, 'White', 1, '2022-09-03 10:33:21', '2022-09-03 10:33:21'),
(9, 3, 'Brown', 1, '2022-09-03 10:33:21', '2022-09-03 10:33:21');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_frame_size`
--

CREATE TABLE `tbl_frame_size` (
  `id` bigint(20) NOT NULL,
  `glass_details_id` bigint(20) NOT NULL,
  `frame_size` varchar(20) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_frame_size`
--

INSERT INTO `tbl_frame_size` (`id`, `glass_details_id`, `frame_size`, `is_active`, `created_at`, `updated_at`) VALUES
(2, 2, 'EXTRA NARROW', 1, '2022-09-03 12:37:08', '2022-09-03 12:37:08'),
(3, 3, ' NARROW', 1, '2022-09-03 15:42:04', '2022-09-03 15:42:04');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_frame_width`
--

CREATE TABLE `tbl_frame_width` (
  `id` bigint(20) NOT NULL,
  `glass_details_id` bigint(20) NOT NULL,
  `frame_width` varchar(20) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_frame_width`
--

INSERT INTO `tbl_frame_width` (`id`, `glass_details_id`, `frame_width`, `is_active`, `created_at`, `updated_at`) VALUES
(2, 2, '129mm', 1, '2022-09-03 12:38:10', '2022-09-03 12:38:10'),
(3, 3, '130mm', 1, '2022-09-03 12:38:10', '2022-09-03 12:38:10');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_glass_categories`
--

CREATE TABLE `tbl_glass_categories` (
  `id` bigint(20) NOT NULL,
  `person_id` bigint(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `image` varchar(20) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_glass_categories`
--

INSERT INTO `tbl_glass_categories` (`id`, `person_id`, `name`, `image`, `is_active`, `created_at`, `updated_at`) VALUES
(2, 1, 'Rimmed', 'Rimmed.png', 1, '2022-09-03 10:45:19', '2022-09-03 10:45:19'),
(3, 1, 'Rimless', 'Rimless.png', 1, '2022-09-03 10:45:19', '2022-09-03 10:45:19'),
(4, 1, 'Semi-Rimmed', 'Semi-Rimmed.png', 1, '2022-09-03 10:45:46', '2022-09-03 10:45:46'),
(5, 2, 'Computer Glasses', 'Computer Glasses.png', 1, '2022-09-03 10:47:10', '2022-09-03 10:47:10'),
(6, 2, 'Eye Glasses', 'Eye Glasses.png', 1, '2022-09-03 10:47:10', '2022-09-03 10:47:10'),
(7, 2, 'Sun Glasses', 'Sun Glasses.png', 1, '2022-09-03 10:47:39', '2022-09-03 10:47:39'),
(8, 3, 'Rectangle', 'Rectangle.png', 1, '2022-09-03 10:49:17', '2022-09-03 10:49:17'),
(9, 3, 'Aviator', 'Aviator.png', 1, '2022-09-03 10:49:17', '2022-09-03 10:49:17'),
(10, 3, 'Hexagon', 'Hexagon.png', 1, '2022-09-03 10:49:46', '2022-09-03 10:49:46');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_glass_details`
--

CREATE TABLE `tbl_glass_details` (
  `id` bigint(20) NOT NULL,
  `glass_categories_id` bigint(20) NOT NULL,
  `image` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `avg_rating` decimal(10,2) NOT NULL,
  `promocode` varchar(30) NOT NULL,
  `old_price` decimal(10,2) NOT NULL,
  `new_price` decimal(10,2) NOT NULL,
  `description` text NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_glass_details`
--

INSERT INTO `tbl_glass_details` (`id`, `glass_categories_id`, `image`, `name`, `avg_rating`, `promocode`, `old_price`, `new_price`, `description`, `is_active`, `created_at`, `updated_at`) VALUES
(2, 6, 'Brown Rectnagle.png', 'Brown Rectnagle', '7.33', 'JZJSJHSJS', '50.00', '100.00', 'WSAXADA', 1, '2022-09-03 11:29:46', '2022-09-03 18:34:03'),
(3, 6, 'Brown Rectnagle.png', 'Brown Rectnagle', '5.00', 'JZJSJHSJS', '50.00', '100.00', 'WSAXADA', 1, '2022-09-03 11:29:46', '2022-09-03 17:38:20'),
(4, 6, 'Brown Rectnagle.png', 'Brown Rectnagle', '5.00', 'JZJSJHSJS', '50.00', '100.00', 'WSAXADA', 1, '2022-09-03 11:29:46', '2022-09-03 17:38:26');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_image`
--

CREATE TABLE `tbl_image` (
  `image_id` bigint(20) NOT NULL,
  `glass_details_id` bigint(20) NOT NULL,
  `image` varchar(20) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_person`
--

CREATE TABLE `tbl_person` (
  `id` bigint(20) NOT NULL,
  `type` enum('Men','Women','Kids') NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_person`
--

INSERT INTO `tbl_person` (`id`, `type`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Men', 1, '2022-09-03 05:12:21', '2022-09-03 05:12:21'),
(2, 'Women', 1, '2022-09-03 05:13:40', '2022-09-03 05:13:40'),
(3, 'Kids', 1, '2022-09-03 05:13:49', '2022-09-03 05:13:49');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_rating`
--

CREATE TABLE `tbl_rating` (
  `id` bigint(20) NOT NULL,
  `glass_details_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `rating` decimal(10,2) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_rating`
--

INSERT INTO `tbl_rating` (`id`, `glass_details_id`, `user_id`, `rating`, `is_active`, `created_at`, `updated_at`) VALUES
(19, 2, 2, '10.10', 1, '2022-09-03 18:07:43', '2022-09-03 18:07:43'),
(21, 2, 2, '4.60', 1, '2022-09-03 18:07:43', '2022-09-03 18:07:43'),
(22, 2, 2, '4.60', 1, '2022-09-03 18:07:43', '2022-09-03 18:07:43'),
(23, 2, 2, '10.00', 1, '2022-09-03 18:07:43', '2022-09-03 18:07:43');

--
-- Triggers `tbl_rating`
--
DELIMITER $$
CREATE TRIGGER `Rating` AFTER INSERT ON `tbl_rating` FOR EACH ROW UPDATE tbl_glass_details SET avg_rating=(SELECT AVG(rating) FROM tbl_rating WHERE tbl_rating.glass_details_id=tbl_glass_details.id) WHERE id=NEW.glass_details_id
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` bigint(20) NOT NULL,
  `social_id` text NOT NULL,
  `login_type` enum('S','F','G') NOT NULL COMMENT ' S-> Simple Signup, F-> Facebook Signup, G-> Google Signup ',
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone_no` varchar(20) NOT NULL,
  `password` varchar(32) NOT NULL,
  `role` enum('User') NOT NULL,
  `profile_image` varchar(32) NOT NULL DEFAULT 'default.png',
  `is_online` tinyint(1) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `last_login` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `social_id`, `login_type`, `name`, `email`, `phone_no`, `password`, `role`, `profile_image`, `is_online`, `is_deleted`, `last_login`, `is_active`, `created_at`, `updated_at`) VALUES
(2, '3123123', 'F', 'Sachsaidn', 'rahulmeenaglc847@gmail.com', '9998545417', '', 'User', 'default.png', 1, 0, '2022-09-02 10:14:17', 1, '2022-09-02 15:04:10', '2022-09-02 15:44:17'),
(3, '', 'S', 'Kishan', 'Kishan@gmail.com', '9558543417', 'ZLzVBH6TQyeplAgVNlEGPA==', 'User', 'default.png', 1, 0, '2022-09-05 07:11:52', 1, '2022-09-02 15:48:49', '2022-09-05 12:41:52'),
(4, '', 'S', 'Vijay', 'Vijay@gmail.com', '9558543416', 'RSr6cIFfLZS1i6PAVDdDWQ==', 'User', 'default.png', 1, 0, '2022-09-03 04:55:42', 1, '2022-09-03 10:25:42', '2022-09-03 10:25:42');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_device`
--

CREATE TABLE `tbl_user_device` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `token` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `device_type` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `device_token` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `uuid` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `os_version` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `device_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `model_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `insertdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_user_device`
--

INSERT INTO `tbl_user_device` (`id`, `user_id`, `token`, `device_type`, `device_token`, `uuid`, `os_version`, `device_name`, `model_name`, `ip`, `insertdate`, `updatetime`) VALUES
(37, 2, '8543hh1yjp6e8tdfqig54wtyvwdtwhtaw2aduloys8xsdavwlqrnas4hr5oxutnx', 'A', 'fdtgDddy', '', '', NULL, '', '', '2022-09-02 09:34:10', '2022-09-02 10:14:17'),
(38, 3, 'cfqo773jmz2hqk1tcyei0cv263c9uk03x5ql40pr38izycgnzzq70twkjc0be0yg', 'I', 'fdtgsDddy', '', '', NULL, '', '', '2022-09-02 10:18:49', '2022-09-05 07:11:52'),
(39, 4, 'n42fr6f0e7qurylxz0k4jf6zeoekn91je5sr39iusm9trzq7iyxrhjtwdwbbujqo', 'I', 'fdtsDddy', '', '', NULL, '', '', '2022-09-03 04:55:42', '2022-09-03 04:55:42');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_otp_details`
--

CREATE TABLE `tbl_user_otp_details` (
  `id` bigint(20) NOT NULL,
  `code` varchar(6) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `phone_no` varchar(16) DEFAULT NULL,
  `otp` varchar(8) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_user_otp_details`
--

INSERT INTO `tbl_user_otp_details` (`id`, `code`, `email`, `phone_no`, `otp`, `is_active`, `created_at`, `updated_at`) VALUES
(4, '+91', NULL, '9998545417', '4587', 1, '2022-09-05 12:04:15', '2022-09-05 12:04:15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_color`
--
ALTER TABLE `tbl_color`
  ADD PRIMARY KEY (`id`),
  ADD KEY `glass_details_id` (`glass_details_id`);

--
-- Indexes for table `tbl_frame_size`
--
ALTER TABLE `tbl_frame_size`
  ADD PRIMARY KEY (`id`),
  ADD KEY `glass_details_id` (`glass_details_id`);

--
-- Indexes for table `tbl_frame_width`
--
ALTER TABLE `tbl_frame_width`
  ADD PRIMARY KEY (`id`),
  ADD KEY `glass_details_id` (`glass_details_id`);

--
-- Indexes for table `tbl_glass_categories`
--
ALTER TABLE `tbl_glass_categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `person_id` (`person_id`);

--
-- Indexes for table `tbl_glass_details`
--
ALTER TABLE `tbl_glass_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `glass_categories_id` (`glass_categories_id`);

--
-- Indexes for table `tbl_image`
--
ALTER TABLE `tbl_image`
  ADD PRIMARY KEY (`image_id`);

--
-- Indexes for table `tbl_person`
--
ALTER TABLE `tbl_person`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_rating`
--
ALTER TABLE `tbl_rating`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user_device`
--
ALTER TABLE `tbl_user_device`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user_otp_details`
--
ALTER TABLE `tbl_user_otp_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_color`
--
ALTER TABLE `tbl_color`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_frame_size`
--
ALTER TABLE `tbl_frame_size`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_frame_width`
--
ALTER TABLE `tbl_frame_width`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_glass_categories`
--
ALTER TABLE `tbl_glass_categories`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_glass_details`
--
ALTER TABLE `tbl_glass_details`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_image`
--
ALTER TABLE `tbl_image`
  MODIFY `image_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_person`
--
ALTER TABLE `tbl_person`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_rating`
--
ALTER TABLE `tbl_rating`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_user_device`
--
ALTER TABLE `tbl_user_device`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `tbl_user_otp_details`
--
ALTER TABLE `tbl_user_otp_details`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_color`
--
ALTER TABLE `tbl_color`
  ADD CONSTRAINT `tbl_color_ibfk_1` FOREIGN KEY (`glass_details_id`) REFERENCES `tbl_glass_details` (`id`);

--
-- Constraints for table `tbl_frame_size`
--
ALTER TABLE `tbl_frame_size`
  ADD CONSTRAINT `tbl_frame_size_ibfk_1` FOREIGN KEY (`glass_details_id`) REFERENCES `tbl_glass_details` (`id`);

--
-- Constraints for table `tbl_frame_width`
--
ALTER TABLE `tbl_frame_width`
  ADD CONSTRAINT `tbl_frame_width_ibfk_1` FOREIGN KEY (`glass_details_id`) REFERENCES `tbl_glass_details` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
