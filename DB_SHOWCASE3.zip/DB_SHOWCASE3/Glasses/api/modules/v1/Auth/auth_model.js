var con = require('../../../config/database');
var GLOBALS = require('../../../config/constants');
var common = require('../../../config/common');
var cryptoLib = require('cryptlib');
var asyncLoop = require('node-async-loop');
var moment = require('moment');
var shaKey = cryptoLib.getHashSha256(GLOBALS.KEY, 32);
var emailTemplate = require('../../../config/template');
const { response } = require('express');
const { t } = require('localizify');


var Auth = {


/*=============================================================================================================================
        Check Unique
=============================================================================================================================*/
/* 

check_unique: function (unique_key, callback) {

    var len = Object.keys(unique_key).length;
    var i = 1;

    asyncLoop(unique_key, function (item, next) {
        //console.log(item);
        // Get object key with: item.key 
        // Get associated value with: item.value
        if (item.value != '' && item.value != undefined) {
            var query = con.query("SELECT * FROM tbl_user WHERE role = 'Customer' AND " + item.key + " = ? ", item.value, function (err, result, _fields) {

                if (!err) {
                    if (result[0] == undefined) {
                        if (len == i) {
                            callback(true, t('text_rest_unique_succ'), 1);
                            return;
                        }
                    } else {
                        //console.log(item.key);
                        callback(false, t('text_rest_already_taken', {
                            field: item.key.replace("_", " ")
                        }), 0);
                        return;
                    }
                } else {
                    callback(false, t('text_rest_already_taken', {
                        field: item.key.replace("_", " ")
                    }), 0);
                    return;

                }
                i++;
                next();
            });
        } else {
            i++;
            next();
        }

    }, function () {
        callback();
    });
},
 */


     /**
     * Function to get details of any users
     * 02-09-2022
     * @param {Login User ID} user_id 
     * @param {Function} callback
     */
      userdetails: function (user_id, callback) {

        con.query("SELECT u.*,concat('" + GLOBALS.S3_BUCKET_ROOT + GLOBALS.USER_IMAGE + "','',u.profile_image) as profile_image,IFNULL(ut.device_token,'') as device_token,IFNULL(ut.device_type,'') as device_type,IFNULL(ut.token,'') as token FROM tbl_user u LEFT JOIN tbl_user_device as ut ON u.id = ut.user_id WHERE u.id = '" + user_id + "' AND u.is_deleted='0' GROUP BY u.id", function (err, result, fields) {
            console.log("Error of Users", err);
            if (!err && result.length > 0) {
                callback(result[0]);
            } else {
                callback(null);
            }
        });
    },


    /**
     * Function for check unique email and phone numbers for users
     * 02-09-2022
     * @param {Login User ID} user_id 
     * @param {Request Data} request 
     * @param {Function} callback 
     */
    checkUniqueFields: function (user_id, request, callback) {

        // Check in database for this email register
        Auth.checkUniqueEmail(user_id, request, function (emailcode, emailmsg, emailUnique) {
            if (emailUnique) {
                Auth.checkUniqueUsername(user_id, request, function (phonecode, phonemsg, phoneUnique) {
                    if (phoneUnique) {
                        callback(phonecode, phonemsg, phoneUnique);
                    } else {
                        callback(phonecode, phonemsg, phoneUnique);
                    }
                });
            } else {
                callback(emailcode, emailmsg, emailUnique);
            }
        });
    },

    /**
     * Function to check email uniqueness
     * 02-09-2022
     * @param {Login User ID} user_id 
     * @param {Request} request 
     * @param {Function} callback 
     */
    checkUniqueEmail: function (user_id, request, callback) {

        if (request.email != undefined && request.email != '') {

            if (user_id != undefined && user_id != '') {
                var uniqueEmail = "SELECT * FROM tbl_user WHERE email = '" + request.email + "' AND is_deleted='0' AND id != '" + user_id + "' ";
            } else {
                var uniqueEmail = "SELECT * FROM tbl_user WHERE email = '" + request.email + "' AND is_deleted='0' ";
            }
            con.query(uniqueEmail, function (error, result, fields) {
                if (!error && result[0] != undefined) {
                    callback('0', {
                        keyword: 'rest_keywords_duplicate_email',
                        components: {}
                    }, false);
                } else {
                    callback('1', "Success", true);
                }
            });

        } else {
            callback('1', "Success", true);
        }
    },

    /**
     * Function to check email uniqueness
     * 02-09-2022
     * @param {Login User ID} user_id 
     * @param {Request} request 
     * @param {Function} callback 
     */
     checkUniqueUsername: function (user_id, request, callback) {

        if (request.username != undefined && request.username != '') {

            if (user_id != undefined && user_id != '') {
                var uniqueUsername = "SELECT * FROM tbl_user WHERE username = '" + request.username + "' AND is_deleted='0' AND id != '" + user_id + "' ";
            } else {
                var uniqueUsername = "SELECT * FROM tbl_user WHERE username = '" + request.username + "' AND is_deleted='0' ";
            }
            con.query(uniqueUsername, function (error, result, fields) {
                if (!error && result[0] != undefined) {
                    callback('0', {
                        keyword: 'rest_keywords_duplicate_username',
                        components: {}
                    }, false);
                } else {
                    callback('1', "Success", true);
                }
            });

        } else {
            callback('1', "Success", true);
        }
    },

    /**
     * Function to update users details
     * 02-09-2022
     * @param {Login User ID} user_id 
     * @param {Update Parameters} upd_params 
     * @param {Function} callback 
     */
    updateCustomer: function (user_id, upd_params, callback) {
        con.query("UPDATE tbl_user SET ? WHERE id = ? ", [upd_params, user_id], function (err, result, fields) {
            if (!err) {
                Auth.userdetails(user_id, function (response, err) {
                    callback(response);
                });
            } else {
                callback(null, err);
            }
        });
    },

    /**
     * Function to signup for users
     * @param {request} request 
     * @param {Function} callback 
     */
    signUpUsers: function (request, callback) {
        Auth.checkUniqueFields('', request, function (uniquecode, uniquemsg, isUnique) {
            if (isUnique) {
                
                var customer = {
                    social_id:(request.social_id != undefined && request.social_id != '')?request.social_id:'',
                    name: request.name,
                    email: (request.email != undefined && request.email != "") ? request.email : '',
                    is_active: '1',
                    is_online: '1',
                    profile_image: 'default.png',
                    phone_no: (request.phone_no != undefined && request.phone_no != "") ? request.phone_no : '',
                    password:(request.password != undefined && request.password != '')?cryptoLib.encrypt(request.password,shaKey,process.env.IV):'',
                    login_type: (request.login_type != undefined && request.login_type != "") ? request.login_type : '',
                };

                con.query('INSERT INTO tbl_user SET ?', customer, function (err, result, fields) {
                    if (!err) {
                        
                        common.checkUpdateDeviceInfo(result.insertId, "Customer", request, function () {
                        
                            Auth.userdetails(result.insertId, function (userprofile, err) {
                                
                                common.generateSessionCode(result.insertId, "Customer", function (Token) {
                        
                                    userprofile.token = Token;
                                    callback('1', {
                                        keyword: 'rest_keywords_user_signup_success',
                                        components: {}
                                    }, userprofile);
                                });
                            });
                        });
                    } else {
                        console.log(err)
                        callback('0', {
                            keyword: 'rest_keywords_user_signup_failed',
                            components: {}
                        }, null);
                    }
                });

            } else {
                callback(uniquecode, uniquemsg, null);
            }
        });
    },


               
    /**
     * Function to check login details of users
     * @param {request} request 
     * @param {Function} callback 
     */
    checkLogin: function (request, callback) {
  
    
        //chek user details via Email    
        if(request.social_id != undefined && request.login_type  != 'S'){         
            var whereCondition = "social_id = '"+request.social_id+"' AND login_type = '"+request.login_type+"'";
        }else{
        var whereCondition = " email='" + request.email + "' ";
        }
        con.query("SELECT * FROM tbl_user where " + whereCondition + " AND is_deleted='0' ", function (err, result, fields) {

            if (!err ) {

                if(result[0] != undefined){

                console.log(result)

                Auth.userdetails(result[0].id, function (userprofile) {

                    if(request.social_id != undefined && request.login_type != 'S'){
                        var flag = 1;
                    }
                    else{
                    var password = cryptoLib.decrypt(result[0].password, shaKey, GLOBALS.IV);
                    if(password === request.password){
                        var flag = 1;
                    }else{
                        var flag = 0;
                    }
                    }
                   if(flag == 1){
                        var updparams = {
                            is_online: "1",
                            last_login: require('node-datetime').create().format('Y-m-d H:M:S'),
                        }
                        // update device information of user
                        common.checkUpdateDeviceInfo(result[0].id, "Customer", request, function () {
                            Auth.updateCustomer(result[0].id, updparams, function (userprofile, error) {
                                common.generateSessionCode(result[0].id, "Customer", function (token) {
                                    userprofile.token = token;
                                    callback('1', {
                                        keyword: 'rest_keywords_user_login_success',
                                        components: {}
                                    }, userprofile);
                                });
                            });
                        });
                    }else{
                        callback('0', {
                            keyword: 'rest_keywords_inactive_accountby_admin',
                            components: {}
                        }, null);

                    }
                });
            }else{
                if(request.social_id != undefined && request.login_type != 'S'){
                    //chek email exitsts or not 
                    callback('11', {
                        keyword: 'text_user_login_new',
                        components: {}
                    }, null);
                    
                }else{
                    callback('0', {
                        keyword: 'text_user_login_fail',
                        components: {}
                    }, null);
                }

            }
            } else {
                callback('0', {
                    keyword: 'rest_keywords_invalid_email',
                    components: {}
                }, null);
            }
        });
    },

    /**
     * Function to send forgot password links
     * @param {request} request 
     * @param {Function} callback 
     */
    forgotPassword: function (request, callback) {

        con.query("SELECT * FROM tbl_user where email='" + request.email + "' AND is_deleted='0' ", function (err, result, fields) {
            if (!err & result[0] != undefined) {

                var updparams = {
                    forgotpassword_token: GLOBALS.APP_NAME + result[0].id,
                    forgotpassword_date: require('node-datetime').create().format('Y-m-d H:M:S')
                }
                Auth.updateCustomer(result[0].id, updparams, function (isupdated) {

                    result[0].encoded_user_id = Buffer.from(result[0].id.toString()).toString('base64');
                    emailTemplate.forgot_password(result[0], function (forgotTemplate) {
                        common.send_email("Forgot Password", request.email, forgotTemplate, function (isSend) {
                            if (isSend) {
                                callback('1', {
                                    keyword: 'rest_keywords_user_forgot_password_success',
                                    components: {}
                                }, result[0]);
                            } else {
                                callback('0', {
                                    keyword: 'rest_keywords_user_forgot_password_failed',
                                    components: {}
                                }, result[0]);
                            }
                        });
                    });
                });
            } else {
                callback('0', {
                    keyword: 'rest_keywords_user_doesnot_exist',
                    components: {}
                }, null);
            }
        });
    },

   
    glass_categories:function(request,callback){
       
        var p = "select * from tbl_glass_categories gc where gc.person_id = "+request.person_id+" AND is_active = '1'";       
         con.query(p,function(err,result){
         
        if(!err){
       
            callback("1", {keyword: "rest_keywords_get_store_details_category_success",components: {},},result);
        }
        else{
       
            callback("0", {keyword: "rest_keywords_get_store_details_category_FAIL",components: {},},null);
        }
  
        })
  },

     
  glass_details:function(request,callback){
       
    var p = "select * from tbl_glass_details gd where gd.glass_categories_id = "+request.glass_categories_id+" AND is_active = '1'";       
     con.query(p,function(err,result){
     
    if(!err){
   
        callback("1", {keyword: "rest_keywords_get_store_details_category_success",components: {},},result);
    }
    else{
   
        callback("0", {keyword: "rest_keywords_get_store_details_category_FAIL",components: {},},null);
    }

    })
},





//ALL Details Of Frame API function
colorList:function(request,callback){

    var p = "select color from tbl_color where glass_details_id ="+request.id+" AND is_active = '1'";       
    con.query(p,function(err,result){
    if(!err){
        callback("1", {keyword: "rest_keywords_get_store_details_category_success",components: {},},result);
    }
    else{
        callback("0", {keyword: "rest_keywords_get_store_details_category_FAIL",components: {},},null);
    }

    })
},

//ALL Details Of Frame API function
frame_size:function(request,callback){

    var p = "select frame_size from tbl_frame_size where glass_details_id ="+request.id+" AND is_active = '1'";       
    con.query(p,function(err,result){
    if(!err){
        callback("1", {keyword: "rest_keywords_get_store_details_category_success",components: {},},result);
    }
    else{
        callback("0", {keyword: "rest_keywords_get_store_details_category_FAIL",components: {},},null);
    }

    })
},

frame_width:function(request,callback){

    var p = "select frame_width from tbl_frame_width where glass_details_id ="+request.id+" AND is_active = '1'";       
    con.query(p,function(err,result){
    if(!err){
        callback("1", {keyword: "rest_keywords_get_store_details_category_success",components: {},},result);
    }
    else{
        callback("0", {keyword: "rest_keywords_get_store_details_category_FAIL",components: {},},null);
    }

    })
},


all_glass_details:function(request,callback){
       
    var p = "select * from tbl_glass_details gd where gd.id = "+request.id+" AND is_active = '1'";       
    con.query(p,function(err,result){
     
    if(!err){
          request.id = result[0].id
          Auth.colorList(request, function (code,message,color,) {
          console.log(color)
         result[0].color = color; 
  

         Auth.frame_size(request, function (code,message,frame_size) {
            console.log(frame_size)
             result[0].frame_size = frame_size; 
             
             Auth.frame_width(request, function (code,message,frame_width) {
                console.log(frame_width)
              result[0].frame_width = frame_width; 
              callback("1", {keyword: "rest_keywords_get_store_details_category_success",components: {},},result);         
       })
      })
  })

    }
    else{
   
             callback("0", {keyword: "rest_keywords_get_store_details_category_FAIL",components: {},},null);
    }

    })
},



/*=============================================================================================================================
        Send or Resend OTP
=============================================================================================================================*/

send_otp: function(req, callback){

     var OTP = Math.floor(1000 + Math.random() * 9000);
    //var OTP = '1234';

     con.query("SELECT * FROM tbl_user_otp_details where phone_no = '"+req.phone_no+"' ", function (err, result, fields) {
        //console.log(err)

        if(!err && result[0] != undefined){

            con.query('UPDATE tbl_user_otp_details SET ? WHERE id = "'+result[0].id+'" ', {otp: OTP}, function (err, result, fields) {

                //console.log(err)
                req.OTP = OTP;
                callback('1', {
                    keyword: 'rest_keyword_category_succses',
                    components: {}
                }, true);
                //Call The Template for otpp[;'0]
                
               /*  emailTemplate.forgot_password(req,function(msg, code){
                    callback(true, msg, code);
                })
 */
            })
        }
        else {

            var params  = {
               code: req.code,
               phone_no: req.phone_no,
               otp: OTP
            }
             con.query('INSERT tbl_user_otp_details SET ? ', params, function (err, result, fields) {
                //console.log(err)
             req.OTP = OTP;
                
             callback('1', {
                keyword: 'rest_keyword_otp_succses',
                components: {}
            }, true);

                /* emailTemplate.forgot_password(req,function(msg, code){
                    callback(true, msg, code);
                }) */
            })
        }
    });

},

/*=============================================================================================================================
      verify_otp, Send or Resend OTP
=============================================================================================================================*/

verify_otp: function(req, callback){

    con.query("SELECT * FROM tbl_user_otp_details where phone_no = '"+req.phone_no+"' AND otp = '"+req.otp+"' ", function (err, result, fields) {

        if(!err && result[0] != undefined){

            var query = con.query("DELETE FROM tbl_user_otp_details WHERE id = '"+result[0].id+"' ", function (err, result, fields) {
            
                callback(true, t('text_customer_otp_verify_succ'),1);
                
            })
        }
        else {
            callback(true, t('text_customer_otp_verify_fail'),0);
        }
    });

},



}
    
module.exports = Auth;
