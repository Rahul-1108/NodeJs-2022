var express = require('express');
var middleware = require('../../../middleware/headerValidator');
var common = require('../../../config/common');
var auth_model = require('./auth_model');
var router = express.Router();
const {default: localizify} = require('localizify');
const { t } = require('localizify');
const Validator = require('Validator');







/*=============================================================================================================================
    Unique Details Check
=============================================================================================================================*/

/* router.post("/unique_details_check", function (req, res) {

    //request method encryption
    middleware.decryption(req, function (request) {
        localizify.setLocale(request.login_language);

        var rules = {
            email: 'required',
            phone_no: 'required',
        }

        const messages = {
            'required': t('required')
        }

        var v = Validator.make(request, rules, messages, {
            'email': t('field_email'),
            'phone_no': t('field_phone_no')
        })

        if (v.fails()) {

            var Validator_errors = v.getErrors();

            for (var key in Validator_errors) {
                error = Validator_errors[key][0];
                break;
            }

            response_data = {
                code: 0,
                message: error
            };

            middleware.encryption(response_data, function (responseData) {
                res.status(200);
                res.json(responseData);
            })
        } else {

            var unique_key = {
                'email': request.email,
                'phone_no': request.phone_no
            };

            auth_model.check_unique(unique_key, function (response, msg, code) {

                response_data = {
                    code: code,
                    message: msg,
                };

                common.encryption(response_data, function (response) {
                    res.status(200);
                    res.json(response);
                })

            }); //check_unique
        } //else
    }); //end decryption
});
 */

/*
 * Signup api for User
 * 02-09-2022
 */
router.post("/signup", function (req, res) {

    // request method decryption
    console.log(req.body)
    middleware.decryption(req, function (request) {
        console.log(request)
        var rules = {
            name: 'required',
            phone_no:'',
            email: 'required',
            password: '',
            device_type: 'required|in:A,I',
            device_token: 'required',
            social_id:'',
        }
        
        const messages = {
            'required': req.language.required,
            'in': req.language.in,
        }

        // checks all validation rules defined above and if error send back response
        if (middleware.checkValidationRules(request, res, rules, messages, {})) {
            auth_model.signUpUsers(request, function (responsecode, responsemsg, responsedata) {
                middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
            });
        }
    });
});


/*
 * Login api for User
 * 02-09-2022
 */
router.post("/login", function (req, res) {

    middleware.decryption(req, function (request) {
        console.log(request)

        var request = request
        var rules = {
            device_token: 'required',
            device_type: 'required|in:A,I',
            email: 'required',
            password: '',
            social_id:'',
            login_type:'required|in:S,F,G',
        }

        const messages = {
            'required': req.language.required,
            'in': req.language.in,
        }

        // checks all validation rules defined above and if error send back response
        if (middleware.checkValidationRules(request, res, rules, messages, {})) {
            auth_model.checkLogin(request, function (responsecode, responsemsg, responsedata) {
                middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
            });
        }
    });
});


/*
 * Forgot password API for users
 * 02-09-2022
 */
router.post("/forgotpassword", function (req, res) {

    middleware.decryption(req, function (request) {

        var request = request
        var rules = {
            email: 'required|email'
        }

        const messages = {
            'required': req.language.required,
            'email': req.language.email,
        }

        // checks all validation rules defined above and if error send back response
        if (middleware.checkValidationRules(request, res, rules, messages, {})) {
            auth_model.forgotPassword(request, function (responsecode, responsemsg, responsedata) {
                middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
            });
        }
    });
});



/*
 * glass_categories API 
 * 03-09-2022
 */
router.post("/glass_categories", function (req, res) {

    middleware.decryption(req, function (request) {

        var request = request
        var rules = {
            person_id:'required'
        }

        const messages = {
            'required': req.language.required,
        }

        // checks all validation rules defined above and if error send back response
        if (middleware.checkValidationRules(request, res, rules, messages, {})) {
            auth_model.glass_categories(request, function (responsecode, responsemsg, responsedata) {
                middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
            });
        }
    });
});


/*
 * glass_details API 
 * 03-09-2022
 */
router.post("/glass_details", function (req, res) {

    middleware.decryption(req, function (request) {

        var request = request
        var rules = {

        glass_categories_id:'required'
        }

        const messages = {
            'required': req.language.required,
        }

        // checks all validation rules defined above and if error send back response
        if (middleware.checkValidationRules(request, res, rules, messages, {})) {
            auth_model.glass_details(request, function (responsecode, responsemsg, responsedata) {
                middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
            });
        }
    });
});


/*
 *All glass_details API 
 * 03-09-2022
 */
router.post("/all_glass_details", function (req, res) {

    middleware.decryption(req, function (request) {

        var request = request
        var rules = {

            id:'required'
        }

        const messages = {
            'required': req.language.required,
        }

        // checks all validation rules defined above and if error send back response
        if (middleware.checkValidationRules(request, res, rules, messages, {})) {
            auth_model.all_glass_details(request, function (responsecode, responsemsg, responsedata) {
                middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
            });
        }
    });
});




/*=============================================================================================================================
            Send OTP
=============================================================================================================================*/

router.post("/send_otp",function(req,res){
        
    //request method encryption
    middleware.decryption(req,function(request){
        localizify.setLocale(request.login_language);
        
        var rules = {
            code: 'required',
            phone_no: 'required',
        }

        const messages = {
            'required': t('required')
        }

        var v = Validator.make(request, rules, messages,
            { 
                //'code': t('field_code') ,
                'phone_no': t('field_phone_no') ,
            })
        
        if (v.fails()) {

            var Validator_errors = v.getErrors();
            
            for (var key in Validator_errors) {
                error = Validator_errors[key][0];
                break;
            }

            response_data = {
                code: 0,
                message: error
            };
            middleware.encryption(response_data,function(responseData){
                res.status(200);
                res.json(responseData);
            })
        }
        else{
            
            auth_model.send_otp(request,function(response, msg, code){
        
                response_data = {
                    code: code,
                    message: msg,
                };

                middleware.encryption(response_data,function(response){
                    res.status(200);
                    res.json(response);
                })
            });//send_otp
                
        }//else
    });//end decryption
});


/*=============================================================================================================================
            Verify OTP
=============================================================================================================================*/

router.post("/verify_otp",function(req,res){
        
    //request method encryption
    middleware.decryption(req,function(request){
        localizify.setLocale(request.login_language);
        
        var rules = {
            code: 'required',
            phone_no: 'required',
            otp: 'required',
        }

        const messages = {
            'required': t('required')
        }

        var v = Validator.make(request, rules, messages,
            { 
                'code': t('field_code') ,
                'phone_no': t('field_phone_no') ,
            })
        
        if (v.fails()) {

            var Validator_errors = v.getErrors();
            
            for (var key in Validator_errors) {
                error = Validator_errors[key][0];
                break;
            }

            response_data = {
                code: '0',
                message: error
            };
            middleware.encryption(response_data,function(responseData){
                res.status(200);
                res.json(responseData);
            })
        }
        else{
            
            auth_model.verify_otp(request,function(response, msg, code){
        
                response_data = {
                    code: code,
                    message: msg,
                };

                middleware.encryption(response_data,function(response){
                    res.status(200);
                    res.json(response);
                })
            });//verify_otp
                
        }//else
    });//end decryption
});






module.exports = router;