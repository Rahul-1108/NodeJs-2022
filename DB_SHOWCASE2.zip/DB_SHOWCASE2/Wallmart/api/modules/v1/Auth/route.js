var express = require('express');
var middleware = require('../../../middleware/headerValidator');
var common = require('../../../config/common');
var auth_model = require('./auth_model');
var router = express.Router();

/*
 * Signup api for User
 * 29-08-2022
 */
router.post("/signup", function (req, res) {

    // request method decryption
    console.log(req.body)
    middleware.decryption(req, function (request) {
        console.log(request)
        var rules = {
            name: 'required',
            phone_no:'',
            email: 'required',
            password: '',
            device_type: 'required|in:A,I',
            device_token: 'required',
            social_id:'',
        }
        
        const messages = {
            'required': req.language.required,
            'in': req.language.in,
        }

        // checks all validation rules defined above and if error send back response
        if (middleware.checkValidationRules(request, res, rules, messages, {})) {
            auth_model.signUpUsers(request, function (responsecode, responsemsg, responsedata) {
                middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
            });
        }
    });
});


/*
 * Login api for User
 * 29-08-2022
 */
router.post("/login", function (req, res) {

    middleware.decryption(req, function (request) {
        console.log(request)

        var request = request
        var rules = {
            device_token: 'required',
            device_type: 'required|in:A,I',
            email: 'required',
            password: '',
            social_id:'',
            login_type:'required|in:S,F,G',
        }

        const messages = {
            'required': req.language.required,
            'in': req.language.in,
        }

        // checks all validation rules defined above and if error send back response
        if (middleware.checkValidationRules(request, res, rules, messages, {})) {
            auth_model.checkLogin(request, function (responsecode, responsemsg, responsedata) {
                middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
            });
        }
    });
});


/*
 * Forgot password API for users
 * 12-04-2022
 */
router.post("/forgotpassword", function (req, res) {

    middleware.decryption(req, function (request) {

        var request = request
        var rules = {
            email: 'required|email'
        }

        const messages = {
            'required': req.language.required,
            'email': req.language.email,
        }

        // checks all validation rules defined above and if error send back response
        if (middleware.checkValidationRules(request, res, rules, messages, {})) {
            auth_model.forgotPassword(request, function (responsecode, responsemsg, responsedata) {
                middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
            });
        }
    });
});


/*
 * Store category
 * 30-08-2022
 */
router.get("/store_category", function (req, res) {

    // request method decryption
    console.log(req.body)
    middleware.decryption(req, function (request) {
    console.log(request)
        var rules = {
            id: '',  
        }
        
        const messages = {
            'required': req.language.required,
            'in': req.language.in,
        }

        // checks all validation rules defined above and if error send back response
        if (middleware.checkValidationRules(request, res, rules, messages, {})) {
            auth_model.store_category(request, function (responsecode, responsemsg, responsedata) {
                middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
            });
        }
    });
});



router.post("/storeList", function (req, res) {
    middleware.decryption(req, function (request) {
    
        var rules = {
            store_categories_id : ''
        }

        const messages = {
            'required': req.language.required,
        }

        // checks all validation rules defined above and if error send back response
        
        if (middleware.checkValidationRules(request, res, rules, messages, {})) {
            console.log(request)
            auth_model.storeList(request, function (responsecode, responsemsg, responsedata) {
                middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
            });
        }
    });
});


//All Data of store product categories and product item
router.get("/storedata", function (req, res) {
    middleware.decryption(req, function (request) {
    
        var rules = {
            store_id : ''
        }

             const messages = {
            'required': req.language.required,
        }

        // checks all validation rules defined above and if error send back response
        
        if (middleware.checkValidationRules(request, res, rules, messages, {})) {
            console.log(request)
            auth_model.storedata(request, function (responsecode, responsemsg, responsedata) {
                middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
            });
        }
    });
});
  


/* //productList
router.get("/productList", function (req, res) {
    middleware.decryption(req, function (request) {
        
        var rules = {
           store_id : 'required',
           latitude:'required',
           longitude:'required'
        }

        const messages = {
            'required': req.language.required,
        }

        // checks all validation rules defined above and if error send back response
        
        if (middleware.checkValidationRules(request, res, rules, messages, {})) {
            auth_model.productList(request, function (responsecode, responsemsg, responsedata) {
                //res.send(responsedata)
                middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
            });
        }
    });
});
 */



//============productList====================
router.post("/productList", function (req, res) {
    
    middleware.decryption(req, function (request) {
    console.log(request);
        var rules = {
            store_id  : 'required'
        }
  
        const messages = {
            'required': req.language.required
        }
  
        // checks all validation rules defined above and if error send back response
        
        if (middleware.checkValidationRules(request, res, rules, messages, {})) {
            auth_model.productList(request, function (responsecode, responsemsg, responsedata) {
            middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata);
            });
        }
    });
});








//Add Rating Api
router.post('/rating', function(req, res){
    middleware.decryption(req, function(request){

        var rating = {
            store_id: 'required',
            rating :'required'
            
        }

        const message = {
            'required' : req.language.required,
            'in': req.language.required,
        }

        if(middleware.checkValidationRules(request, res, rating, message, {})) {
            auth_model.add_rating(request, function(responsecode, responsemsg, responsedata){
                middleware.sendresponse(req, res, 200, responsecode, responsemsg, responsedata)
            })
        }
    })
});


module.exports = router;