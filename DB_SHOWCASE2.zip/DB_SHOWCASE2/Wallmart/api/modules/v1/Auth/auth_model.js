var con = require('../../../config/database');
var GLOBALS = require('../../../config/constants');
var common = require('../../../config/common');
var cryptoLib = require('cryptlib');
var asyncLoop = require('node-async-loop');
var moment = require('moment');
var shaKey = cryptoLib.getHashSha256(GLOBALS.KEY, 32);
var emailTemplate = require('../../../config/template');
const { response } = require('express');

var Auth = {


     /**
     * Function to get details of any users
     * 12-04-2022
     * @param {Login User ID} user_id 
     * @param {Function} callback
     */
      userdetails: function (user_id, callback) {

        con.query("SELECT u.*,concat('" + GLOBALS.S3_BUCKET_ROOT + GLOBALS.USER_IMAGE + "','',u.profile_image) as profile_image,IFNULL(ut.device_token,'') as device_token,IFNULL(ut.device_type,'') as device_type,IFNULL(ut.token,'') as token FROM tbl_user u LEFT JOIN tbl_user_device as ut ON u.id = ut.user_id WHERE u.id = '" + user_id + "' AND u.is_deleted='0' GROUP BY u.id", function (err, result, fields) {
            console.log("Error of Users", err);
            if (!err && result.length > 0) {
                callback(result[0]);
            } else {
                callback(null);
            }
        });
    },


    /**
     * Function for check unique email and phone numbers for users
     * 12-04-2022
     * @param {Login User ID} user_id 
     * @param {Request Data} request 
     * @param {Function} callback 
     */
    checkUniqueFields: function (user_id, request, callback) {

        // Check in database for this email register
        Auth.checkUniqueEmail(user_id, request, function (emailcode, emailmsg, emailUnique) {
            if (emailUnique) {
                Auth.checkUniqueUsername(user_id, request, function (phonecode, phonemsg, phoneUnique) {
                    if (phoneUnique) {
                        callback(phonecode, phonemsg, phoneUnique);
                    } else {
                        callback(phonecode, phonemsg, phoneUnique);
                    }
                });
            } else {
                callback(emailcode, emailmsg, emailUnique);
            }
        });
    },

    /**
     * Function to check email uniqueness
     * 12-04-2022
     * @param {Login User ID} user_id 
     * @param {Request} request 
     * @param {Function} callback 
     */
    checkUniqueEmail: function (user_id, request, callback) {

        if (request.email != undefined && request.email != '') {

            if (user_id != undefined && user_id != '') {
                var uniqueEmail = "SELECT * FROM tbl_user WHERE email = '" + request.email + "' AND is_deleted='0' AND id != '" + user_id + "' ";
            } else {
                var uniqueEmail = "SELECT * FROM tbl_user WHERE email = '" + request.email + "' AND is_deleted='0' ";
            }
            con.query(uniqueEmail, function (error, result, fields) {
                if (!error && result[0] != undefined) {
                    callback('0', {
                        keyword: 'rest_keywords_duplicate_email',
                        components: {}
                    }, false);
                } else {
                    callback('1', "Success", true);
                }
            });

        } else {
            callback('1', "Success", true);
        }
    },

    /**
     * Function to check email uniqueness
     * 12-04-2022
     * @param {Login User ID} user_id 
     * @param {Request} request 
     * @param {Function} callback 
     */
     checkUniqueUsername: function (user_id, request, callback) {

        if (request.username != undefined && request.username != '') {

            if (user_id != undefined && user_id != '') {
                var uniqueUsername = "SELECT * FROM tbl_user WHERE username = '" + request.username + "' AND is_deleted='0' AND id != '" + user_id + "' ";
            } else {
                var uniqueUsername = "SELECT * FROM tbl_user WHERE username = '" + request.username + "' AND is_deleted='0' ";
            }
            con.query(uniqueUsername, function (error, result, fields) {
                if (!error && result[0] != undefined) {
                    callback('0', {
                        keyword: 'rest_keywords_duplicate_username',
                        components: {}
                    }, false);
                } else {
                    callback('1', "Success", true);
                }
            });

        } else {
            callback('1', "Success", true);
        }
    },

    /**
     * Function to update users details
     * 12-04-2022
     * @param {Login User ID} user_id 
     * @param {Update Parameters} upd_params 
     * @param {Function} callback 
     */
    updateCustomer: function (user_id, upd_params, callback) {
        con.query("UPDATE tbl_user SET ? WHERE id = ? ", [upd_params, user_id], function (err, result, fields) {
            if (!err) {
                Auth.userdetails(user_id, function (response, err) {
                    callback(response);
                });
            } else {
                callback(null, err);
            }
        });
    },

    /**
     * Function to signup for users
     * @param {request} request 
     * @param {Function} callback 
     */
    signUpUsers: function (request, callback) {
        Auth.checkUniqueFields('', request, function (uniquecode, uniquemsg, isUnique) {
            if (isUnique) {
                
                var customer = {
                    social_id:(request.social_id != undefined && request.social_id != '')?request.social_id:'',
                    name: request.name,
                    email: (request.email != undefined && request.email != "") ? request.email : '',
                    is_active: '1',
                    is_online: '1',
                    profile_image: 'default.png',
                    phone_no: (request.phone_no != undefined && request.phone_no != "") ? request.phone_no : '',
                    password:(request.password != undefined && request.password != '')?cryptoLib.encrypt(request.password,shaKey,process.env.IV):'',
                    login_type: (request.login_type != undefined && request.login_type != "") ? request.login_type : '',
                };

                con.query('INSERT INTO tbl_user SET ?', customer, function (err, result, fields) {
                    if (!err) {
                        
                        common.checkUpdateDeviceInfo(result.insertId, "Customer", request, function () {
                        
                            Auth.userdetails(result.insertId, function (userprofile, err) {
                                
                                common.generateSessionCode(result.insertId, "Customer", function (Token) {
                        
                                    userprofile.token = Token;
                                    callback('1', {
                                        keyword: 'rest_keywords_user_signup_success',
                                        components: {}
                                    }, userprofile);
                                });
                            });
                        });
                    } else {
                        console.log(err)
                        callback('0', {
                            keyword: 'rest_keywords_user_signup_failed',
                            components: {}
                        }, null);
                    }
                });

            } else {
                callback(uniquecode, uniquemsg, null);
            }
        });
    },


               
    /**
     * Function to check login details of users
     * @param {request} request 
     * @param {Function} callback 
     */
    checkLogin: function (request, callback) {
  
    
        //chek user details via Email    
        if(request.social_id != undefined && request.login_type  != 'S'){         
            var whereCondition = "social_id = '"+request.social_id+"' AND login_type = '"+request.login_type+"'";
        }else{
        var whereCondition = " email='" + request.email + "' ";
        }
        con.query("SELECT * FROM tbl_user where " + whereCondition + " AND is_deleted='0' ", function (err, result, fields) {

            if (!err ) {

                if(result[0] != undefined){

                console.log(result)

                Auth.userdetails(result[0].id, function (userprofile) {

                    if(request.social_id != undefined && request.login_type != 'S'){
                        var flag = 1;
                    }
                    else{
                    var password = cryptoLib.decrypt(result[0].password, shaKey, GLOBALS.IV);
                    if(password === request.password){
                        var flag = 1;
                    }else{
                        var flag = 0;
                    }
                    }
                   if(flag == 1){
                        var updparams = {
                            is_online: "1",
                            last_login: require('node-datetime').create().format('Y-m-d H:M:S'),
                        }
                        // update device information of user
                        common.checkUpdateDeviceInfo(result[0].id, "Customer", request, function () {
                            Auth.updateCustomer(result[0].id, updparams, function (userprofile, error) {
                                common.generateSessionCode(result[0].id, "Customer", function (token) {
                                    userprofile.token = token;
                                    callback('1', {
                                        keyword: 'rest_keywords_user_login_success',
                                        components: {}
                                    }, userprofile);
                                });
                            });
                        });
                    }else{
                        callback('0', {
                            keyword: 'rest_keywords_inactive_accountby_admin',
                            components: {}
                        }, null);

                    }
                });
            }else{
                if(request.social_id != undefined && request.login_type != 'S'){
                    //chek email exitsts or not 
                    callback('11', {
                        keyword: 'text_user_login_new',
                        components: {}
                    }, null);
                    
                }else{
                    callback('0', {
                        keyword: 'text_user_login_fail',
                        components: {}
                    }, null);
                }

            }
            } else {
                callback('0', {
                    keyword: 'rest_keywords_invalid_email',
                    components: {}
                }, null);
            }
        });
    },

    /**
     * Function to send forgot password links
     * @param {request} request 
     * @param {Function} callback 
     */
    forgotPassword: function (request, callback) {

        con.query("SELECT * FROM tbl_user where email='" + request.email + "' AND is_deleted='0' ", function (err, result, fields) {
            if (!err & result[0] != undefined) {

                var updparams = {
                    forgotpassword_token: GLOBALS.APP_NAME + result[0].id,
                    forgotpassword_date: require('node-datetime').create().format('Y-m-d H:M:S')
                }
                Auth.updateCustomer(result[0].id, updparams, function (isupdated) {

                    result[0].encoded_user_id = Buffer.from(result[0].id.toString()).toString('base64');
                    emailTemplate.forgot_password(result[0], function (forgotTemplate) {
                        common.send_email("Forgot Password", request.email, forgotTemplate, function (isSend) {
                            if (isSend) {
                                callback('1', {
                                    keyword: 'rest_keywords_user_forgot_password_success',
                                    components: {}
                                }, result[0]);
                            } else {
                                callback('0', {
                                    keyword: 'rest_keywords_user_forgot_password_failed',
                                    components: {}
                                }, result[0]);
                            }
                        });
                    });
                });
            } else {
                callback('0', {
                    keyword: 'rest_keywords_user_doesnot_exist',
                    components: {}
                }, null);
            }
        });
    },


    
    store_category: function(request, callback){
    
        con.query("SELECT * FROM tbl_store_categories  ",  function(err, result){
            console.log(err);
            if(!err){
                callback('1', {
                    keyword: 'rest_keywords_store_category_show_success',
                    components: {}
                },result );
            } else {
                callback('0', {
                    keyword: 'rest_keywords_store_category_show_failed',
                    components: {}
                }, null);
            }

        })
    },
  
    


    storeList:function(request,callback){
        var whereCondition=""
        if(request.store_categories_id != undefined && request.store_categories_id != ''){
        whereCondition = " s.store_categories_id = '"+request.store_categories_id+"' AND";
        }
        var p=`SELECT s.name,s.location,s.avg_rating,s.email,s.phone_no,(3959 * 2 * ASIN(SQRT(POWER(SIN((u.latitude - s.latitude) * pi()/180 /2),(2) ) + COS(u.latitude * pi() / 180) * COS(s.latitude * pi()/180) * POWER(SIN((u.longitude - s.longitude) * pi()/180 /2), (2))))) as miles_away FROM tbl_store s LEFT JOIN tbl_user u ON u.id=s.user_id where ${whereCondition} s.is_active='1'`
        con.query(p,function(err,result){
          if(!err){
         console.log(err)
         console.log(result)
         callback("1", {keyword: "rest_keywords_get_store_details_category_success",components: {},},result);
          }
          else{
            console.log(err)
            callback("0", {keyword: "rest_keywords_get_store_details_category_fail",components: {},},result);
          }
    
          })
      },

        
      storedata:function(request,callback){
        if(request.store_id != undefined && request.store_id != ''){
        }
        var Q =`SELECT * FROM tbl_product_categories` 
        
        con.query(Q,function(err,result){
          if(!err){

            var response=[];
            var response1={};
            asyncLoop(result,function(item,next){
                var p=`SELECT pc.product_name,p.id,p.name,p.image,p.about,p.price FROM tbl_product_categories pc LEFT JOIN tbl_product_item p on pc.id=p.product_categories_id where p.is_active='1' AND pc.id=${item.id}` 
             con.query(p,function(err1,result1){
                if(!err1){
                    response1={}
                    response1.category=item.product_name;
                    response1.data=result1;
                    response.push(response1);
                    next()
                }else{
                    console.log(err1);process.exit();
                }
               
             })
            },function(){
                console.log(response)
                callback("1", {keyword: "rest_keywords_get_store_data_category_success",components: {},},response);
            })
         console.log(err)
         console.log(result)
         //callback("1", {keyword: "rest_keywords_get_store_data_category_success",components: {},},result);
          }
          else{
            console.log(err)
            callback("0", {keyword: "rest_keywords_get_store_data_category_fail",components: {},},result);
          }
    
          })
      },
 


    /* productList:function(request,callback){

        var response = {};
     var p="SELECT name,location,avg_rating,email,phone_no,(3959 * 2 * ASIN(SQRT(POWER(SIN(("+request.latitude+" - latitude) * pi()/180 /2),(2) ) + COS("+request.latitude+" * pi() / 180) * COS(latitude * pi()/180) * POWER(SIN(("+request.longitude+" - longitude) * pi()/180 /2), (2))))) as miles_away FROM tbl_store where store_id = "+request.store_id+" AND is_active='1' ";
         
        con.query(p,function(err,result){
            
          if(!err){
            response.store_detail = result[0];
                Auth.product_Category(request, function (get_product_category) {
                    response.item_detail = get_product_category;
                    result[0].product_category = get_product_category 
                callback("1", {keyword: "rest_keywords_get_store_details_category_success",components: {},},response);         
         })
          }
          else{
         
                callback("0", {keyword: "rest_keywords_get_store_details_category_FAIL",components: {},},null);
          }
    
          })

    },
  
    product_Category: function (request, callback) {
        
         con.query("SELECT id,product_name FROM tbl_product_categories where store_id = '" + request.store_id + "'",
             function (err, result) {
               console.log(result)
                
                 if (!err && result.length > 0) {   
                     asyncLoop(result, function (item, next)
                     {
                         console.log(item)
                         Auth.product_items(item.id, function (code,message,get_product_category) {
                             item.product = get_product_category; 
                             next();
                         });
                     },function ()
                     {
                        callback("1", {keyword: "rest_keywords_get_store_details_category_success",components: {},},result);
                     })
                 
                 } else {
                     callback("0", {keyword: "rest_keywords_get_store_details_category_success",components: {},},null);
                 }
             });
    },

    product_items: function (request, callback) {
       // console.log("ddd")
       
         con.query("SELECT * FROM tbl_product_item where product_categories_id = '" + request + "'",
         

             function (err, result) {
                 if (!err && result.length > 0) {   
                    //console.log(result)
                     
                     callback("1", {keyword: "rest_keywords_get_store_details_category_success",components: {},},result);
                 } else {
                     callback("0", {keyword: "rest_keywords_get_store_details_category_success",components: {},},null);
                 }
             });
    },
 */
      

      /*
    productList ()
    */
    productList: function (request, callback) {
        whereCondition = " s.store_id  = '" + request.store_id  + "' AND";

        var p = `SELECT s.name,s.location,s.avg_rating,s.email,s.phone_no,(3959 * 2 * ASIN(SQRT(POWER(SIN((u.latitude - s.latitude) * pi()/180 /2),(2) ) + COS(u.latitude * pi() / 180) * COS(s.latitude * pi()/180) * POWER(SIN((u.longitude - s.longitude) * pi()/180 /2), (2))))) as miles_away FROM tbl_store s LEFT JOIN tbl_user u ON u.id=s.user_id where ${whereCondition} s.is_active='1'`;

        con.query(p, function (err, result) {
            console.log(err)
            if (!err) {
                Auth.product_Category(request.store_id,function (code, message, get_product_category) {
                    // console.log(get_product_category)
                    result[0].product_category = get_product_category
                    callback("1", { 
                        keyword: "rest_keywords_get_store_details_category_success", 
                        components: {}, 
                    }, result);
                })
            }
            else {
                callback("0", { 
                    keyword: "rest_keywords_get_store_details_category_FAIL", 
                    components: {}, 
                }, null);
            }
        })
    },

    /*
    Product category ()
    */
    product_Category: function (store_id, callback) {

        con.query("select id , product_name from tbl_product_categories  where store_id  = '" + store_id  + "'",
            function (err, result, fields) {

                if (!err && result.length > 0) {
                    
                    //console.log(result)
                    asyncLoop(result, function (item, next) {
                       // console.log(item.product_categories_id)
                        
                        Auth.product_items(item.id, function (code, message, data) {
                            item.product = data;
                            next();
                        })
                    }, function () {
                        callback("1", { 
                            keyword: "rest_keywords_get_product_Category_success", 
                            components: {}, 
                        }, result);
                    })
                    //console.log(item)


                } else {
                    callback("0", { 
                        keyword: "rest_keywords_get_product_Category_Fail", 
                        components: {}, 
                    }, null);
                }
            });
    },

    /*
    product Iteam ()
    */
    product_items: function (product_categories_id, callback) {
    console.log(product_categories_id)
        con.query("select * from tbl_product_item where product_categories_id  = '" + product_categories_id  + "'",
            function (err, result) {
                console.log(err) 
                if (!err && result.length > 0) {
                    callback("1", { 
                        keyword: "rest_keywords_get_product_items_success", 
                        components: {}, 
                    }, result);
                } else {
                    callback("0", { 
                        keyword: "rest_keywords_get_product_items_Fail", 
                        components: {}, 
                    }, null);
                }
            });
    },










      add_rating: function(request, callback){
        var rating = {
            user_id: request.user_id,
            store_id : request.store_id,
            rating: request.rating,
        }
        con.query(`INSERT INTO tbl_rating SET ?`, rating, function(err, result, fields){
            if(!err){
                callback('1', {
                    keyword: 'rest_keywords_rating_add_success',
                    components: {}
                }, null);
            } else {
                callback('0', {
                    keyword: 'rest_keywords_rating_add_failed',
                    components: {}
                }, null);
            }

        })
    },

      
    
}
    
module.exports = Auth;
