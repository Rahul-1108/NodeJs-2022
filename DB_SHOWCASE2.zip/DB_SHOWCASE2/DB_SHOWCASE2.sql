-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 05, 2022 at 02:41 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `DB_SHOWCASE2`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product_categories`
--

CREATE TABLE `tbl_product_categories` (
  `id` bigint(20) NOT NULL,
  `store_id` bigint(20) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_product_categories`
--

INSERT INTO `tbl_product_categories` (`id`, `store_id`, `product_name`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 1, 'Milk', 1, '2022-07-01 00:00:00', '2022-09-05 09:49:17'),
(2, 1, 'Ice-cream', 0, '2022-07-01 00:00:00', '2022-09-05 09:49:21'),
(3, 1, 'Bread', 1, '2022-07-01 00:00:00', '2022-09-05 09:49:25'),
(4, 1, 'Biscuit', 1, '2022-07-01 00:00:00', '2022-07-02 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product_item`
--

CREATE TABLE `tbl_product_item` (
  `id` bigint(20) NOT NULL,
  `product_categories_id` bigint(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `about` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_product_item`
--

INSERT INTO `tbl_product_item` (`id`, `product_categories_id`, `name`, `image`, `about`, `price`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 4, 'OREO ', 'OREO.png', 'So nice Milk', '100.00', 1, '2022-07-01 00:00:00', '2022-09-01 13:30:06'),
(2, 1, 'Shakti milk', 'Shakti milk.png', 'So Amazing Milk', '200.00', 1, '2022-07-01 00:00:00', '2022-07-02 00:00:00'),
(3, 3, 'Venila Ice-cream', 'Venila Ice-cream.png', 'So nice Ice-crea,', '300.00', 0, '2022-07-01 00:00:00', '2022-07-02 00:00:00'),
(4, 2, 'Chocolate Ice-cream', 'Chocolate Ice-cream.png', 'So Amazing Ice-cream', '400.00', 1, '2022-07-01 00:00:00', '2022-07-02 00:00:00'),
(7, 1, 'Gold milk', 'Gold milk.png', 'DDSDQADDX', '30.00', 1, '2022-09-01 15:58:35', '2022-09-01 15:58:35');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_rating`
--

CREATE TABLE `tbl_rating` (
  `rating_id` bigint(20) NOT NULL,
  `store_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `rating` decimal(10,2) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_rating`
--

INSERT INTO `tbl_rating` (`rating_id`, `store_id`, `user_id`, `rating`, `is_active`, `created_at`, `updated_at`) VALUES
(17, 1, 17, '7.50', 1, '2022-09-03 09:52:04', '2022-09-03 09:52:04'),
(18, 1, 17, '7.50', 1, '2022-09-03 09:52:17', '2022-09-03 09:52:17'),
(19, 1, 17, '7.50', 1, '2022-09-03 09:52:36', '2022-09-03 09:52:36'),
(20, 1, 17, '7.50', 1, '2022-09-03 10:20:45', '2022-09-03 10:20:45'),
(21, 1, 17, '7.50', 1, '2022-09-03 10:20:53', '2022-09-03 10:20:53');

--
-- Triggers `tbl_rating`
--
DELIMITER $$
CREATE TRIGGER `Rating` AFTER INSERT ON `tbl_rating` FOR EACH ROW UPDATE tbl_store SET avg_rating = (SELECT IFNULL(ROUND(AVG(rating),1),0) FROM  tbl_rating WHERE tbl_rating.store_id = tbl_store.store_id) WHERE store_id = NEW.store_id
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_store`
--

CREATE TABLE `tbl_store` (
  `store_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `store_categories_id` bigint(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  `latitude` varchar(50) NOT NULL,
  `longitude` varchar(50) NOT NULL,
  `avg_rating` decimal(10,1) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone_no` varchar(50) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_store`
--

INSERT INTO `tbl_store` (`store_id`, `user_id`, `store_categories_id`, `name`, `image`, `location`, `latitude`, `longitude`, `avg_rating`, `email`, `phone_no`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 17, 1, 'Walmart', 'walmart.png', 'Ahmedabad', '22.3072', '73.1812', '7.5', 'Walmart@gmail.com', '9635214556', 1, '2022-07-01 00:00:00', '2022-09-03 09:52:04'),
(2, 19, 3, 'Foodery', 'Foodery.png', 'Washingtone', '23.5880', '72.3693', '4.8', 'royalacserve@gmail.com', '9156885624', 0, '2022-07-01 00:00:00', '2022-08-31 15:44:57'),
(3, 20, 2, 'American home shield', 'American home shield.png', 'Washingtone', '22,3072', '73.1812', '4.8', 'Americanhomeshield@gmail.com', '8521234567', 1, '2022-07-29 14:53:24', '2022-08-31 15:45:15'),
(4, 21, 4, 'Pharmasift', 'Pharmasift.png', 'BlueCardion', '23.5880', '72.3693', '10.0', 'Pharmasift@gmail.com', '7411325889', 1, '2022-07-29 14:53:24', '2022-08-31 15:45:29');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_store_categories`
--

CREATE TABLE `tbl_store_categories` (
  `id` bigint(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_store_categories`
--

INSERT INTO `tbl_store_categories` (`id`, `name`, `is_active`, `created_at`, `updated_at`) VALUES
(0, 'All', 1, '2022-09-01 10:15:33', '2022-09-01 10:15:40'),
(1, 'HouseHold', 1, '2022-07-01 00:00:00', '2022-07-01 00:00:00'),
(2, 'Grocery', 1, '2022-07-01 00:00:00', '2022-07-01 00:00:00'),
(3, 'Furniture', 0, '2022-07-01 00:00:00', '2022-07-01 00:00:00'),
(4, 'Pharmacy', 1, '2022-07-01 00:00:00', '2022-07-01 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` bigint(20) NOT NULL,
  `social_id` text NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone_no` varchar(20) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `role` enum('User','Vendor') NOT NULL,
  `login_type` enum('S','F','G') NOT NULL COMMENT ' S-> Simple Signup, F-> Facebook Signup, G-> Google Signup ',
  `is_online` tinyint(1) NOT NULL DEFAULT 0,
  `profile_image` varchar(32) NOT NULL,
  `latitude` varchar(32) DEFAULT NULL,
  `longitude` varchar(32) DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `last_login` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `social_id`, `name`, `phone_no`, `email`, `password`, `role`, `login_type`, `is_online`, `profile_image`, `latitude`, `longitude`, `is_deleted`, `last_login`, `is_active`, `created_at`, `updated_at`) VALUES
(17, 'Chintan', 'Chintan', '3692581470', 'Chintan@gmail.com', '', 'User', 'F', 1, 'default.png', '23.0225', '72.5714', 0, '2022-09-03 13:27:04', 1, '2022-08-30 10:01:25', '2022-08-30 10:01:25'),
(19, '', 'Rahul', '9998543416', 'rahulmeenaglc847@gmail.com', 'vvw+FzkkEHPGWPeygMfCBQ==', 'User', 'S', 1, 'default.png', '23.0225', '72.5714', 0, '2022-08-30 10:33:27', 1, '2022-08-30 10:33:27', '2022-08-30 10:33:27'),
(20, '', 'Sachin', '9998543417', 'Sachin@gmail.com', '9nFtM/ZYNixkkHzhCvjRXQ==', 'User', 'S', 1, 'default.png', '23.0225', '72.5714', 0, '2022-08-30 11:57:26', 1, '2022-08-30 11:57:26', '2022-08-30 11:57:26'),
(21, '', 'Vikash', '9998543414', 'Vikash@gmail.com', 'Vyt2JDOBcWmILX761UoSaA==', 'User', 'S', 1, 'default.png', '23.0225', '72.5714', 0, '2022-08-30 13:39:21', 1, '2022-08-30 13:39:21', '2022-08-30 13:39:21'),
(22, '', 'Vansh', '9998543415', 'Vansh@gmail.com', 'JiwIU+M/bPC20bn+/OeCFQ==', 'User', 'S', 1, 'default.png', '23.0225', '72.5714', 0, '2022-08-30 13:45:32', 1, '2022-08-30 13:45:32', '2022-08-30 13:45:32'),
(24, '3123123', 'Sachsain', '9998543417', 'Sachsain@gmail.com', '', 'User', 'F', 1, 'default.png', NULL, NULL, 0, '2022-09-01 06:16:46', 1, '2022-09-01 06:16:46', '2022-09-01 06:16:46'),
(26, '', 'Kishan', '9558543417', 'Kishan@gmail.com', 'W+cnNKvClr/cG3UFQfyB/A==', 'User', 'S', 1, 'default.png', NULL, NULL, 0, '2022-09-01 09:27:23', 1, '2022-09-01 09:27:23', '2022-09-01 09:27:23'),
(29, '', 'Surya', '9566543417', 'Surya@gmail.com', 'yhF67efhSoSANdOleKln7Q==', 'User', 'S', 1, 'default.png', NULL, NULL, 0, '2022-09-01 13:47:32', 1, '2022-09-01 13:47:32', '2022-09-01 13:47:32'),
(30, '3123123', 'Sachsaidn', '9998545417', 'Sachsasin@gmail.com', '', 'User', 'F', 1, 'default.png', NULL, NULL, 0, '2022-09-01 13:53:35', 1, '2022-09-01 13:53:35', '2022-09-01 13:53:35'),
(31, '312313', 'Sachin', '9998545418', 'Sachin11@gmail.com', '', 'User', 'F', 1, 'default.png', NULL, NULL, 0, '2022-09-03 03:40:37', 1, '2022-09-03 03:40:37', '2022-09-03 03:40:37'),
(32, '31313', 'Anuj', '9998545419', 'Anuj11@gmail.com', '', 'User', 'F', 1, 'default.png', NULL, NULL, 0, '2022-09-03 13:28:22', 1, '2022-09-03 13:28:22', '2022-09-03 13:28:22');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_device`
--

CREATE TABLE `tbl_user_device` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `token` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `device_type` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `device_token` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `uuid` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `os_version` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `device_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `model_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `insertdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_user_device`
--

INSERT INTO `tbl_user_device` (`id`, `user_id`, `token`, `device_type`, `device_token`, `uuid`, `os_version`, `device_name`, `model_name`, `ip`, `insertdate`, `updatetime`) VALUES
(22, 17, 'o1avycahieui2phclcqb369twl5oje0n94ix08bcgajstn1pasq5079lmxyr3z6v', 'A', 'fdsdtgDddy', '', '', NULL, '', '', '2022-08-30 10:01:25', '2022-09-03 13:27:04'),
(23, 19, 'xtyx90bavgr2if3nv55y4audoyktgt19clgfl5kgjpm9x7chkc0glplagkqfx52p', 'I', 'fddsdtgDddy', '', '', NULL, '', '', '2022-08-30 10:33:27', '2022-08-30 10:33:27'),
(24, 20, 'rvfj5640tvuf9xy6uwx19gjme5d79x2481afy9qqq3thu8oom9qn3wy8cd4v7nbw', 'A', 'fdtgDddy', '', '', NULL, '', '', '2022-08-30 11:57:26', '2022-08-30 11:57:26'),
(25, 21, 'h9hu8vdn2x3cg8sr0pthg2xaicjlmu3pwzu5caxe3ygoj4fr4c3efnf9jrqhlv2k', 'I', 'fdtgdy', '', '', NULL, '', '', '2022-08-30 13:39:21', '2022-08-30 13:39:21'),
(26, 22, 'plmh91cqujlg3mfl9oj2xuz5mb41wxgzvdxwslh8qi615uryg1x7eg5fubohgya8', 'A', 'fdtgssdy', '', '', NULL, '', '', '2022-08-30 13:45:32', '2022-08-30 13:45:32'),
(27, 23, '7ak8pbkjuc83lo8iqpj6v6cb2wbmbhtc60vsv7z5mauz4oz7hdocrh8z3otu7nug', 'A', 'fdtgDddy', '', '', NULL, '', '', '2022-09-01 06:15:59', '2022-09-01 06:15:59'),
(28, 24, 'fkydm8e1cyxtdap952r2g1vbo9v2vbesyu2mpldzoyedzyiz3nqadxkhbydu5wth', 'A', 'fdtgDddy', '', '', NULL, '', '', '2022-09-01 06:16:46', '2022-09-01 06:16:46'),
(29, 25, 'ngm556me4f3cne9phmj1ux5fvfs68a6hurq2bq62l27fkxj9e6ygu0ojhtj4pojm', 'A', 'fdtgDddy', '', '', NULL, '', '', '2022-09-01 06:30:57', '2022-09-01 06:30:57'),
(30, 26, '8kqtgi4oivgjdugwhaivrzrhxo82j5s5o8ckqm0grt16sdfhtg49ldqxl7g0hwz0', 'A', 'fdtgDddy', '', '', NULL, '', '', '2022-09-01 09:27:23', '2022-09-01 09:27:23'),
(33, 29, 'fdskoi2qenb4edvfjv4h35vhb5rmczd728f5z9o9ydq5u2n5cwlnkgcpwowok3rv', 'A', 'fdtgDddy', '', '', NULL, '', '', '2022-09-01 13:47:32', '2022-09-01 13:47:32'),
(34, 30, 'dt2h4mkll8sy3ytj2cfk4fbg7aq68dbfis9ma4vy5afuypq801jny8k3aa718bnm', 'A', 'fdtgDddy', '', '', NULL, '', '', '2022-09-01 13:53:35', '2022-09-01 13:53:35'),
(35, 31, 'fxbhg5sc0drzgg8qpajdmxfnsseov76opim0o65wrxtg2gj3uipxqv6se4oj6cts', 'A', 'fdtgddy', '', '', NULL, '', '', '2022-09-03 03:40:37', '2022-09-03 03:40:37'),
(36, 32, 'wze5xbol0wyjd8ccw18of8uz5pskxhhvrr4wknpepj3xuwhvanm9082im9bf7k07', 'A', 'fdtddy', '', '', NULL, '', '', '2022-09-03 13:28:22', '2022-09-03 13:28:22');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_verify`
--

CREATE TABLE `tbl_verify` (
  `verify_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `phone_no` varchar(20) NOT NULL,
  `otp` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_verify`
--

INSERT INTO `tbl_verify` (`verify_id`, `user_id`, `phone_no`, `otp`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 1, '1234567890', 2568, 1, '2022-07-29 00:00:00', '2022-07-29 17:44:13'),
(2, 3, '1234567892', 2538, 1, '2022-07-29 00:00:00', '2022-07-29 17:49:58'),
(3, 2, '1234567891', 2548, 1, '2022-07-29 00:00:00', '2022-07-29 17:50:16'),
(4, 4, '1234567893', 2558, 0, '2022-07-29 00:00:00', '2022-07-29 17:50:30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_product_categories`
--
ALTER TABLE `tbl_product_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_product_item`
--
ALTER TABLE `tbl_product_item`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_rating`
--
ALTER TABLE `tbl_rating`
  ADD PRIMARY KEY (`rating_id`);

--
-- Indexes for table `tbl_store`
--
ALTER TABLE `tbl_store`
  ADD PRIMARY KEY (`store_id`);

--
-- Indexes for table `tbl_store_categories`
--
ALTER TABLE `tbl_store_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user_device`
--
ALTER TABLE `tbl_user_device`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_verify`
--
ALTER TABLE `tbl_verify`
  ADD PRIMARY KEY (`verify_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_product_categories`
--
ALTER TABLE `tbl_product_categories`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_product_item`
--
ALTER TABLE `tbl_product_item`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_rating`
--
ALTER TABLE `tbl_rating`
  MODIFY `rating_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tbl_store`
--
ALTER TABLE `tbl_store`
  MODIFY `store_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_store_categories`
--
ALTER TABLE `tbl_store_categories`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `tbl_user_device`
--
ALTER TABLE `tbl_user_device`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `tbl_verify`
--
ALTER TABLE `tbl_verify`
  MODIFY `verify_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_product_categories`
--
ALTER TABLE `tbl_product_categories`
  ADD CONSTRAINT `tbl_product_categories_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `tbl_store` (`store_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
