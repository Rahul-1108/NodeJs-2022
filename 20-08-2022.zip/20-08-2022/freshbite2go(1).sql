-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 20, 2022 at 09:02 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `freshbite2go`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin_details`
--

CREATE TABLE `tbl_admin_details` (
  `id` bigint(20) NOT NULL,
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `profile_image` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default-user.png',
  `role` enum('S','A') COLLATE utf8_unicode_ci NOT NULL COMMENT 'A -> Admin, S -> Super Admin',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `insertdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_admin_details`
--

INSERT INTO `tbl_admin_details` (`id`, `name`, `email`, `password`, `profile_image`, `role`, `is_active`, `insertdate`, `updatetime`) VALUES
(1, 'Admin fr', 'admin@admin.com', 't/tUSo8nxr7SzZdQ3G10Iw==', 'default-user.png', 'S', 1, '2020-01-08 05:30:15', '2020-05-06 05:23:06');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bank_detail`
--

CREATE TABLE `tbl_bank_detail` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `bank_name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `account_holder_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `routing_number` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `account_number` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `merchant_account_id` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `bank_document` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `currency` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  `ssn_last` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `zipcode` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `insertdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_card_detail`
--

CREATE TABLE `tbl_card_detail` (
  `id` bigint(11) NOT NULL,
  `user_id` bigint(11) NOT NULL,
  `card_id` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `fingerprint` text COLLATE utf8_unicode_ci NOT NULL,
  `card_holder_name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `card_number` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `credit_card_token` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `expiration_date` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `insertdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

CREATE TABLE `tbl_cart` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `chef_id` bigint(20) NOT NULL,
  `total_cart_item` int(11) NOT NULL,
  `insertdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart_details`
--

CREATE TABLE `tbl_cart_details` (
  `id` bigint(20) NOT NULL,
  `cart_id` int(11) NOT NULL,
  `dish_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `spicy_level` enum('Basic','Mild','Spicy') COLLATE utf8_unicode_ci NOT NULL,
  `notes` text COLLATE utf8_unicode_ci NOT NULL,
  `insertdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_chef_certificate`
--

CREATE TABLE `tbl_chef_certificate` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL COMMENT 'Chef ID',
  `certificate` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `insertdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_chef_document`
--

CREATE TABLE `tbl_chef_document` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL COMMENT 'Chef ID',
  `document` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `insertdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_chef_food_speciality`
--

CREATE TABLE `tbl_chef_food_speciality` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL COMMENT 'chef id',
  `food_type_id` text COLLATE utf8_unicode_ci NOT NULL,
  `insertdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_chef_rating_review`
--

CREATE TABLE `tbl_chef_rating_review` (
  `id` bigint(20) NOT NULL,
  `order_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `chef_id` bigint(20) NOT NULL,
  `rating` double(5,1) NOT NULL,
  `review` text COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `insertdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Triggers `tbl_chef_rating_review`
--
DELIMITER $$
CREATE TRIGGER `Add Rating` AFTER INSERT ON `tbl_chef_rating_review` FOR EACH ROW UPDATE tbl_user SET rating = (SELECT IFNULL(ROUND(AVG(rating),1),0) FROM  tbl_chef_rating_review WHERE tbl_chef_rating_review.chef_id = tbl_user.id) WHERE id = NEW.chef_id
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_chef_working_hours`
--

CREATE TABLE `tbl_chef_working_hours` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL COMMENT 'Chef ID',
  `days` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `available` tinyint(1) NOT NULL DEFAULT 1,
  `insertdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact_details`
--

CREATE TABLE `tbl_contact_details` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `subject` text COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `insertdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_country`
--

CREATE TABLE `tbl_country` (
  `id` bigint(11) NOT NULL,
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `dial_code` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `short_code` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `currency` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `insertdate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_country`
--

INSERT INTO `tbl_country` (`id`, `name`, `dial_code`, `short_code`, `currency`, `is_active`, `insertdate`) VALUES
(1, 'Australia', '+61', 'AU', 'AUD', 1, '2018-03-21 18:53:23'),
(2, 'Austria', '+43', 'AT', 'EUR', 1, '2018-03-21 18:53:23'),
(3, 'Belgium', '+32', 'BE', 'EUR', 1, '2018-07-04 00:07:07'),
(4, 'Brazil', '+55', 'BR', 'BRL', 1, '2018-07-04 00:07:07'),
(5, 'Canada', '+1', 'CA', 'CAD', 1, '2018-03-21 19:13:19'),
(6, 'Denmark', '+45', 'DK', 'EUR', 1, '2018-03-21 19:16:34'),
(7, 'Finland', '+358', 'FI', 'EUR', 1, '2018-03-21 19:17:48'),
(8, 'France', '+33', 'FR', 'EUR', 1, '2018-03-21 19:18:22'),
(9, 'Germany', '+49', 'DE', 'EUR', 1, '2018-03-21 19:15:53'),
(10, 'Hong Kong', '+852', 'HK', 'HKD', 1, '2018-03-21 19:19:45'),
(11, 'Ireland', '+353', 'IE', 'EUR', 1, '2018-03-21 19:20:29'),
(12, 'Italy', '+39', 'IT', 'EUR', 1, '2018-03-21 19:21:09'),
(13, 'Japan', '+81', 'JP', 'JPY', 1, '2018-03-21 19:21:51'),
(14, 'Luxembourg', '+352', 'LU', 'EUR', 1, '2018-03-21 19:22:25'),
(15, 'Mexico', '+52', 'MX', 'MXN', 1, '2018-07-04 00:07:07'),
(16, 'Netherlands', '+31', 'NL', 'EUR', 1, '2018-03-21 19:22:59'),
(17, 'New Zealand', '+64', 'NZ', 'NZD', 1, '2018-03-21 19:24:16'),
(18, 'Norway', '+47', 'NO', 'EUR', 1, '2018-03-21 19:23:37'),
(19, 'Portugal', '+351', 'PT', 'EUR', 1, '2018-03-21 19:24:52'),
(20, 'Singapore', '+65', 'SG', 'SGD', 1, '2018-03-21 19:26:02'),
(21, 'Spain', '+34', 'ES', 'EUR', 1, '2018-03-21 19:17:12'),
(22, 'Sweden', '+46', 'SE', 'EUR', 1, '2018-03-21 19:25:22'),
(23, 'Switzerland', '+41', 'CH', 'CHF', 1, '2018-03-21 19:15:12'),
(24, 'United Kingdom', '+44', 'GB', 'GBP', 1, '2018-03-21 19:19:02'),
(25, 'United States', '+1', 'US', 'USD', 1, '2018-03-21 19:26:36');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer_rating_review`
--

CREATE TABLE `tbl_customer_rating_review` (
  `id` bigint(20) NOT NULL,
  `order_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `chef_id` bigint(20) NOT NULL,
  `rating` double(5,1) NOT NULL,
  `review` text COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `insertdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_customer_rating_review`
--

INSERT INTO `tbl_customer_rating_review` (`id`, `order_id`, `user_id`, `chef_id`, `rating`, `review`, `is_active`, `insertdate`, `updatetime`) VALUES
(1, 1, 1, 1, 5.0, 'dsfdsgdfg', 1, '2022-07-27 08:55:46', '2022-07-27 08:55:46'),
(2, 2, 1, 1, 2.0, 'fdsgdfgfdfgf', 1, '2022-07-27 08:56:23', '2022-07-27 08:56:23');

--
-- Triggers `tbl_customer_rating_review`
--
DELIMITER $$
CREATE TRIGGER `Add Customer Rating` AFTER INSERT ON `tbl_customer_rating_review` FOR EACH ROW UPDATE tbl_user SET rating = (SELECT IFNULL(ROUND(AVG(rating),1),0) FROM  tbl_customer_rating_review WHERE tbl_customer_rating_review.user_id = tbl_user.id) WHERE id = NEW.user_id
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_favorite_chef`
--

CREATE TABLE `tbl_favorite_chef` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `chef_id` bigint(20) NOT NULL,
  `insertdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_food_type`
--

CREATE TABLE `tbl_food_type` (
  `id` bigint(20) NOT NULL,
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `color` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `insertdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_food_type`
--

INSERT INTO `tbl_food_type` (`id`, `name`, `image`, `color`, `is_active`, `insertdate`, `updatetime`) VALUES
(1, 'Chinese', 'Chinies.png', '#f69999', 1, '2019-12-27 04:04:07', '2020-03-05 06:51:21'),
(2, 'Indian', '1600465523.jpeg', '#8aaef5', 1, '2019-12-27 04:04:07', '2020-09-19 09:45:25'),
(3, 'Italian', 'Italian.png', '#fbcf63', 1, '2019-12-27 04:05:43', '2020-03-05 08:07:51'),
(4, 'South Indian', '1600465736.jpg', '#15a92f', 1, '2019-12-27 04:05:43', '2020-09-19 09:48:58'),
(5, 'Desserts', '1600465793.jpg', '#b181fa', 1, '2019-12-27 04:05:43', '2020-09-19 09:49:55'),
(6, 'Arabian Food', 'Arabian.png', '#fbab6f', 1, '2019-12-27 04:05:43', '2020-03-05 06:53:03'),
(7, 'Sea Food', 'Sea_Food.png', '#63e2fb', 1, '2019-12-27 04:05:43', '2020-03-05 06:53:27'),
(8, 'Beverage', 'Beverage.png', '#f9abe7', 1, '2019-12-27 04:05:57', '2020-03-05 06:51:33'),
(9, 'Diat Food', '1600465720.jpg', '#b181fa', 1, '2020-03-05 08:24:05', '2020-09-19 09:48:42');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_menu`
--

CREATE TABLE `tbl_menu` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `menu_category_id` bigint(20) NOT NULL,
  `dish_name` text COLLATE utf8_unicode_ci NOT NULL,
  `currency` varchar(4) COLLATE utf8_unicode_ci NOT NULL,
  `dish_price` double(5,2) NOT NULL,
  `dish_image` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `insertdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_menu_category`
--

CREATE TABLE `tbl_menu_category` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL COMMENT 'chef id',
  `category` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `insertdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_notification_details`
--

CREATE TABLE `tbl_notification_details` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action_id` int(11) NOT NULL,
  `notification_lang_tag` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `type` enum('Request','Preparing','Ready','Completed','Cancelled') COLLATE utf8_unicode_ci NOT NULL,
  `is_unread` tinyint(1) NOT NULL DEFAULT 1,
  `insertdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `id` bigint(20) NOT NULL,
  `order_no` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` bigint(20) NOT NULL COMMENT 'From tbl_login',
  `chef_id` bigint(20) NOT NULL COMMENT 'From tbl_login',
  `transaction_id` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `order_datetime` datetime NOT NULL,
  `arrival_time` datetime NOT NULL,
  `total_item` int(11) NOT NULL,
  `sub_total` double(10,2) NOT NULL,
  `delivery_charge` double(10,2) NOT NULL,
  `tax_amount` double(10,2) NOT NULL,
  `grand_total` double(10,2) NOT NULL,
  `app_earning` double(10,2) NOT NULL,
  `chef_earning` double(10,2) NOT NULL,
  `is_tip` tinyint(1) NOT NULL DEFAULT 0,
  `tip_amount` double(10,2) NOT NULL,
  `is_utensils` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('Request','Preparing','Ready','Completed','Cancelled') COLLATE utf8_unicode_ci NOT NULL,
  `cancelled_by` enum('','Chef','Customer') COLLATE utf8_unicode_ci NOT NULL,
  `cancel_reason` text COLLATE utf8_unicode_ci NOT NULL,
  `refund_amount` double(10,2) NOT NULL,
  `request_status` enum('Pending','Approved','Rejected') COLLATE utf8_unicode_ci NOT NULL,
  `payment_status` enum('Pending','Completed','Refund') COLLATE utf8_unicode_ci NOT NULL,
  `is_review` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0 -> No review, 1 -> Given review, 2 -> Skip review',
  `is_customer_review` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0 -> No review, 1 -> Given review, 2 -> Skip review ',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `insertdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_details`
--

CREATE TABLE `tbl_order_details` (
  `id` bigint(20) NOT NULL,
  `order_id` int(11) NOT NULL,
  `dish_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` double(10,2) NOT NULL,
  `spicy_level` enum('Basic','Mild','Spicy') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Mild',
  `notes` text COLLATE utf8_unicode_ci NOT NULL,
  `insertdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_setting_details`
--

CREATE TABLE `tbl_setting_details` (
  `id` bigint(20) NOT NULL,
  `attribute_name` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `attribute_value` text COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `insertdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatedate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_setting_details`
--

INSERT INTO `tbl_setting_details` (`id`, `attribute_name`, `attribute_value`, `is_active`, `insertdate`, `updatedate`) VALUES
(1, 'project_name', 'Fresh Bite 2 Go', 1, '2017-06-04 08:43:45', '2018-12-24 22:50:38'),
(2, 'header_logo', 'logo.png', 1, '2017-06-04 08:44:05', '2017-06-04 08:44:05'),
(3, 'fav_icon', 'favicon.png', 1, '2017-06-04 08:44:05', '2017-08-24 11:36:35'),
(4, 'from_email', 'info@freshbite2go.com', 1, '2017-06-04 08:44:05', '2018-10-04 02:03:22'),
(5, 'fogot_password_limit', '12', 1, '2017-08-31 13:27:15', '2017-08-31 13:27:15'),
(6, 'min_price', '10', 1, '2017-08-31 13:27:15', '2017-08-31 13:27:15'),
(7, 'max_price', '100', 1, '2017-08-31 13:27:15', '2017-08-31 13:27:15'),
(8, 'earning', '25', 1, '2017-08-31 13:27:15', '2020-04-17 15:56:26');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` bigint(20) NOT NULL,
  `stripe_customer_id` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  `mobile_number` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `address` text COLLATE utf8_unicode_ci NOT NULL,
  `latitude` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `longitude` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `language` enum('en','fr') COLLATE utf8_unicode_ci NOT NULL COMMENT 'en -> English, fr -> French',
  `notification` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1 -> on, 0 -> off',
  `about_me` text COLLATE utf8_unicode_ci NOT NULL,
  `verify_code` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `role` enum('Customer','Chef') COLLATE utf8_unicode_ci NOT NULL,
  `login` enum('login','logout') COLLATE utf8_unicode_ci NOT NULL,
  `chef_profile_status` int(11) NOT NULL,
  `profile_image` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `rating` float(5,1) NOT NULL,
  `is_chef_available` tinyint(1) NOT NULL DEFAULT 0,
  `login_type` enum('S') COLLATE utf8_unicode_ci NOT NULL COMMENT 'S -> Simple Signup',
  `is_online` tinyint(1) NOT NULL DEFAULT 0,
  `last_login` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `is_verify` tinyint(1) NOT NULL DEFAULT 0,
  `insertdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `stripe_customer_id`, `name`, `email`, `username`, `code`, `mobile_number`, `password`, `image`, `address`, `latitude`, `longitude`, `country`, `language`, `notification`, `about_me`, `verify_code`, `role`, `login`, `chef_profile_status`, `profile_image`, `rating`, `is_chef_available`, `login_type`, `is_online`, `last_login`, `is_active`, `is_deleted`, `is_verify`, `insertdate`, `updatetime`) VALUES
(1, '', 'sonali', 'sonalih@hyperlinkinfosystem.net.in', 'sonali23', '+91', '9898875710', '62NTg0wTW+U0lMnCmBzVKw==', 'default.jpg', 'dsafd', '', '', '', 'en', 1, '', '', 'Customer', 'login', 0, '', 3.5, 0, 'S', 0, '0000-00-00 00:00:00', 1, 0, 1, '2020-09-21 15:14:21', '2022-08-20 06:20:51'),
(7, '', 'sonali', 'sonalihsdsa@hyperlinkinfosystem.net.in', 'sonali23dsd', '', '', 'xrrc5+BTgI7S5Oky85HrtQ==', '', 'gota', '', '', '', 'en', 1, '', '', 'Customer', 'login', 0, 'default.png', 0.0, 0, 'S', 1, '2022-08-20 12:29:24', 1, 0, 0, '2022-08-20 06:48:14', '2022-08-20 06:59:24');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_device`
--

CREATE TABLE `tbl_user_device` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `token` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `device_type` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `device_token` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `uuid` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `os_version` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `device_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `model_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `insertdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_user_device`
--

INSERT INTO `tbl_user_device` (`id`, `user_id`, `token`, `device_type`, `device_token`, `uuid`, `os_version`, `device_name`, `model_name`, `ip`, `insertdate`, `updatetime`) VALUES
(1, 1, 'dbhskfgvdsyvyfgvsyfyg', 'A', 'dsadasfdsf', 'fdsfds', 'a', 'mi', 'dsadsdfd', '24.4343.432.3', '2022-08-17 06:55:27', '2022-08-17 06:55:27'),
(4, 6, '', 'A', 'fkjdsbfhbdjbh', '', '', '', '', '', '2022-08-20 06:47:26', '2022-08-20 06:47:26'),
(6, 7, 'jmjl85y1efmj2e95ph3hzdvi1uj7p4nav4l99psbjkagx65k4ef3wlqpwjszd1g4', 'A', 'fkjdsbfhbdjbh', '', '', '', '', '', '2022-08-20 06:59:24', '2022-08-20 06:59:24');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_otp_details`
--

CREATE TABLE `tbl_user_otp_details` (
  `id` bigint(20) NOT NULL,
  `code` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  `mobile_number` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `otp` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `insertdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin_details`
--
ALTER TABLE `tbl_admin_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_bank_detail`
--
ALTER TABLE `tbl_bank_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_card_detail`
--
ALTER TABLE `tbl_card_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_cart_details`
--
ALTER TABLE `tbl_cart_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_chef_certificate`
--
ALTER TABLE `tbl_chef_certificate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_chef_document`
--
ALTER TABLE `tbl_chef_document`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_chef_food_speciality`
--
ALTER TABLE `tbl_chef_food_speciality`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_chef_rating_review`
--
ALTER TABLE `tbl_chef_rating_review`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_chef_working_hours`
--
ALTER TABLE `tbl_chef_working_hours`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_contact_details`
--
ALTER TABLE `tbl_contact_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_country`
--
ALTER TABLE `tbl_country`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_customer_rating_review`
--
ALTER TABLE `tbl_customer_rating_review`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_favorite_chef`
--
ALTER TABLE `tbl_favorite_chef`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_food_type`
--
ALTER TABLE `tbl_food_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_menu`
--
ALTER TABLE `tbl_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_menu_category`
--
ALTER TABLE `tbl_menu_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_notification_details`
--
ALTER TABLE `tbl_notification_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order_details`
--
ALTER TABLE `tbl_order_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_setting_details`
--
ALTER TABLE `tbl_setting_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user_device`
--
ALTER TABLE `tbl_user_device`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user_otp_details`
--
ALTER TABLE `tbl_user_otp_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin_details`
--
ALTER TABLE `tbl_admin_details`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_bank_detail`
--
ALTER TABLE `tbl_bank_detail`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_card_detail`
--
ALTER TABLE `tbl_card_detail`
  MODIFY `id` bigint(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_cart_details`
--
ALTER TABLE `tbl_cart_details`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_chef_certificate`
--
ALTER TABLE `tbl_chef_certificate`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_chef_document`
--
ALTER TABLE `tbl_chef_document`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_chef_food_speciality`
--
ALTER TABLE `tbl_chef_food_speciality`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_chef_rating_review`
--
ALTER TABLE `tbl_chef_rating_review`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_chef_working_hours`
--
ALTER TABLE `tbl_chef_working_hours`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_contact_details`
--
ALTER TABLE `tbl_contact_details`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_country`
--
ALTER TABLE `tbl_country`
  MODIFY `id` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `tbl_customer_rating_review`
--
ALTER TABLE `tbl_customer_rating_review`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_favorite_chef`
--
ALTER TABLE `tbl_favorite_chef`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_food_type`
--
ALTER TABLE `tbl_food_type`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_menu`
--
ALTER TABLE `tbl_menu`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_menu_category`
--
ALTER TABLE `tbl_menu_category`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_notification_details`
--
ALTER TABLE `tbl_notification_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_order_details`
--
ALTER TABLE `tbl_order_details`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_setting_details`
--
ALTER TABLE `tbl_setting_details`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_user_device`
--
ALTER TABLE `tbl_user_device`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_user_otp_details`
--
ALTER TABLE `tbl_user_otp_details`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
