-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 08, 2022 at 03:14 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `DB_SHOWCASE4`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

CREATE TABLE `tbl_cart` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `dish_id` bigint(20) NOT NULL,
  `total_cart_items` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_cart`
--

INSERT INTO `tbl_cart` (`id`, `user_id`, `dish_id`, `total_cart_items`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 11, '2022-09-07 08:49:01', '2022-09-07 11:45:13'),
(2, 2, 1, 1, '2022-09-07 09:31:02', '2022-09-07 09:51:20'),
(3, 3, 1, 10, '2022-09-07 10:16:43', '2022-09-07 11:21:38'),
(4, 1, 2, 15, '2022-09-07 11:48:37', '2022-09-07 11:51:02');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart_details`
--

CREATE TABLE `tbl_cart_details` (
  `id` int(11) NOT NULL,
  `cart_id` bigint(11) NOT NULL,
  `dish_id` bigint(11) NOT NULL,
  `qty` bigint(11) NOT NULL,
  `spicy_level` enum('Basic','Mild','Spicy') NOT NULL DEFAULT 'Mild',
  `notes` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cuisine`
--

CREATE TABLE `tbl_cuisine` (
  `id` bigint(20) NOT NULL,
  `quesing_name` varchar(50) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_cuisine`
--

INSERT INTO `tbl_cuisine` (`id`, `quesing_name`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Italian', 1, '2022-09-06 09:04:35', '2022-09-06 09:04:35'),
(2, 'Chinese', 1, '2022-09-06 09:04:35', '2022-09-06 09:04:35'),
(3, 'Drinks', 1, '2022-09-06 09:04:35', '2022-09-06 09:04:35'),
(4, 'Punjabi', 1, '2022-09-06 09:04:35', '2022-09-06 09:04:35');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_dish`
--

CREATE TABLE `tbl_dish` (
  `id` bigint(20) NOT NULL,
  `restaurant_id` bigint(20) NOT NULL,
  `cuisine_id` bigint(20) NOT NULL,
  `image` varchar(256) NOT NULL,
  `name` varchar(50) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `about` text NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_dish`
--

INSERT INTO `tbl_dish` (`id`, `restaurant_id`, `cuisine_id`, `image`, `name`, `price`, `about`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'Neapolitan Pizza.png', 'Neapolitan Pizza', '1500.00', 'Neapolitan Pizza', 1, '2022-09-06 09:20:02', '2022-09-06 09:20:16'),
(2, 1, 1, 'st.Louis Pizza.png', 'st.Louis Pizza', '1000.00', 'st.Louis Pizza', 1, '2022-09-06 09:20:02', '2022-09-06 09:20:16'),
(3, 1, 1, 'Neapolitan Pizza-2.png', 'Neapolitan Pizza-2', '1200.00', 'Neapolitan Pizza-2.', 1, '2022-09-06 09:20:02', '2022-09-06 09:20:16'),
(4, 1, 1, 'st.Lious Pizza-2.png', 'st.Lious Pizza-2', '1200.00', 'st.Lious Pizza-2.', 1, '2022-09-06 09:20:02', '2022-09-06 09:20:16');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `order_datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `arrival_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `restaurant_id` bigint(20) NOT NULL,
  `order_no` int(11) NOT NULL DEFAULT 0,
  `total` int(11) NOT NULL,
  `discount_amount` int(11) NOT NULL,
  `service_charge` double(8,2) NOT NULL,
  `sub_total` double(16,2) NOT NULL,
  `grand_total` double(16,2) NOT NULL,
  `status` enum('Pending','Prepared','Out for deliver','Cancelled') NOT NULL,
  `payment_method` enum('Cash','Online') NOT NULL,
  `transaction_Id` varchar(256) NOT NULL DEFAULT '0',
  `rating` float(5,1) NOT NULL DEFAULT 0.0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`id`, `user_id`, `order_datetime`, `arrival_time`, `restaurant_id`, `order_no`, `total`, `discount_amount`, `service_charge`, `sub_total`, `grand_total`, `status`, `payment_method`, `transaction_Id`, `rating`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 1, '2022-09-08 12:35:25', '2022-09-08 12:35:25', 1, 0, 500, 200, 20.00, 320.00, 320.00, 'Pending', 'Cash', '0', 0.0, 1, '2022-09-08 12:35:25', '2022-09-08 12:35:25'),
(2, 1, '2022-09-08 13:13:35', '2022-09-08 13:13:35', 1, 0, 500, 200, 20.00, 320.00, 320.00, 'Pending', 'Cash', '0', 0.0, 1, '2022-09-08 13:13:35', '2022-09-08 13:13:35'),
(3, 1, '2022-09-08 13:13:49', '2022-09-08 13:13:49', 1, 0, 500, 200, 20.00, 320.00, 320.00, 'Pending', 'Cash', '0', 0.0, 1, '2022-09-08 13:13:49', '2022-09-08 13:13:49');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_details`
--

CREATE TABLE `tbl_order_details` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `order_id` bigint(20) NOT NULL,
  `dish_id` bigint(20) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` double(16,2) NOT NULL,
  `sub_total` double(16,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_order_details`
--

INSERT INTO `tbl_order_details` (`id`, `user_id`, `order_id`, `dish_id`, `qty`, `price`, `sub_total`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 3, 3, 100.00, 300.00, '2022-09-08 12:35:25', '2022-09-08 12:35:25'),
(2, 1, 1, 4, 4, 100.00, 400.00, '2022-09-08 12:35:25', '2022-09-08 12:35:25'),
(3, 1, 2, 3, 3, 100.00, 300.00, '2022-09-08 13:13:35', '2022-09-08 13:13:35'),
(4, 1, 2, 4, 4, 100.00, 400.00, '2022-09-08 13:13:35', '2022-09-08 13:13:35'),
(5, 1, 3, 3, 3, 100.00, 300.00, '2022-09-08 13:13:49', '2022-09-08 13:13:49'),
(6, 1, 3, 4, 4, 100.00, 400.00, '2022-09-08 13:13:49', '2022-09-08 13:13:49');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_restaurant_details`
--

CREATE TABLE `tbl_restaurant_details` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `location` varchar(256) NOT NULL,
  `image` varchar(256) NOT NULL,
  `avg_rating` enum('1','2','3','4','5') NOT NULL,
  `total_review` int(11) NOT NULL,
  `about` text NOT NULL,
  `latitude` varchar(256) NOT NULL,
  `longitude` varchar(256) NOT NULL,
  `is_open` tinyint(1) NOT NULL DEFAULT 1,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_restaurant_details`
--

INSERT INTO `tbl_restaurant_details` (`id`, `user_id`, `name`, `location`, `image`, `avg_rating`, `total_review`, `about`, `latitude`, `longitude`, `is_open`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 1, 'High Finnace Restaurant', 'Newyork', 'High Finnace Restaurant.png', '1', 9, 'High Finnace Restaurant', '40.7128', '74.0060', 1, 1, '2022-09-06 07:03:51', '2022-09-07 11:54:03'),
(2, 1, 'Avenue Restaurant', 'Newyork', 'Avenue Restaurant.png', '2', 1, 'Avenue Restaurant', '40.7128', '74.0060', 1, 1, '2022-09-06 07:03:51', '2022-09-07 11:54:07'),
(3, 1, '5 Star Restuarant', 'Newyork', '5 Star Restuarant.png', '5', 1, '5 Star Restuarant', '40.7128', '74.0060', 1, 1, '2022-09-06 07:03:51', '2022-09-07 11:54:11'),
(4, 1, 'Queens Metro Store', 'Newyork', 'Queens Metro Store.png', '1', 1, 'Queens Metro Store', '40.7128', '74.0060', 1, 0, '2022-09-06 07:03:51', '2022-09-07 11:54:16');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_review`
--

CREATE TABLE `tbl_review` (
  `id` bigint(20) NOT NULL,
  `review` text NOT NULL,
  `restaurent_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `rating` enum('1','2','3','4','5') NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_review`
--

INSERT INTO `tbl_review` (`id`, `review`, `restaurent_id`, `user_id`, `rating`, `is_active`, `created_at`, `updated_at`) VALUES
(3, 'Good', 1, 1, '1', 1, '2022-09-06 10:04:58', '2022-09-06 10:04:58'),
(4, 'Good', 1, 1, '1', 1, '2022-09-06 10:04:58', '2022-09-06 10:04:58'),
(8, 'Good', 1, 1, '1', 1, '2022-09-06 10:04:58', '2022-09-06 10:04:58'),
(9, 'Good', 1, 1, '1', 1, '2022-09-06 10:04:58', '2022-09-06 10:04:58'),
(10, 'Good', 1, 1, '4', 1, '2022-09-06 10:04:58', '2022-09-06 10:04:58');

--
-- Triggers `tbl_review`
--
DELIMITER $$
CREATE TRIGGER `Review_Rating` AFTER INSERT ON `tbl_review` FOR EACH ROW BEGIN update `DB_SHOWCASE4`.`tbl_restaurant_details` 
set total_review = total_review + 1 , avg_rating = (select avg(rating) from tbl_review where tbl_review.restaurent_id = tbl_restaurant_details.id)
where id = new.restaurent_id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_time`
--

CREATE TABLE `tbl_time` (
  `id` bigint(20) NOT NULL,
  `restaurant_id` bigint(20) NOT NULL,
  `opning_time` datetime NOT NULL DEFAULT current_timestamp(),
  `closing_time` datetime NOT NULL DEFAULT current_timestamp(),
  `Day` enum('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_time`
--

INSERT INTO `tbl_time` (`id`, `restaurant_id`, `opning_time`, `closing_time`, `Day`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 1, '2022-09-06 14:58:13', '2022-09-06 14:58:13', 'Monday', 1, '2022-09-06 09:28:13', '2022-09-06 09:28:13');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` bigint(20) NOT NULL,
  `social_id` text NOT NULL,
  `login_type` enum('S','F','G') NOT NULL COMMENT ' S-> Simple Signup, F-> Facebook Signup, G-> Google Signup ',
  `name` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `password` varchar(32) NOT NULL,
  `role` enum('User') NOT NULL,
  `location` varchar(32) DEFAULT NULL,
  `latitude` varchar(32) DEFAULT NULL,
  `longitude` varchar(32) DEFAULT NULL,
  `is_online` tinyint(1) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `last_login` timestamp NOT NULL DEFAULT current_timestamp(),
  `profile_image` varchar(32) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `social_id`, `login_type`, `name`, `email`, `phone_number`, `password`, `role`, `location`, `latitude`, `longitude`, `is_online`, `is_deleted`, `last_login`, `profile_image`, `is_active`, `created_at`, `updated_at`) VALUES
(1, '', 'S', 'Priyank', 'PriyankVasovya@gmail.com', '9998543416', 'R2qYgy88WAd0jyU5Mba1mA==', 'User', 'Jersey City', '40.7178', '74.0060', 1, 0, '2022-09-07 12:04:12', 'default.png', 1, '2022-09-06 05:56:52', '2022-09-07 12:04:12'),
(2, '', 'S', 'Ishan', 'IshanKishan@gmail.com', '9998543417', 'aMxLV4NmEXTnFKZAyJuCwQ==', 'User', NULL, NULL, NULL, 1, 0, '2022-09-07 09:26:01', 'default.png', 1, '2022-09-07 09:26:01', '2022-09-07 09:26:01'),
(3, '', 'S', 'Vijay', 'Vijay@gmail.com', '9998543418', 'RSr6cIFfLZS1i6PAVDdDWQ==', 'User', NULL, NULL, NULL, 1, 0, '2022-09-07 10:13:57', 'default.png', 1, '2022-09-07 10:13:57', '2022-09-07 10:13:57');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_device`
--

CREATE TABLE `tbl_user_device` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `token` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `device_type` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `device_token` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `uuid` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `os_version` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `device_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `model_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `insertdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_user_device`
--

INSERT INTO `tbl_user_device` (`id`, `user_id`, `token`, `device_type`, `device_token`, `uuid`, `os_version`, `device_name`, `model_name`, `ip`, `insertdate`, `updatetime`) VALUES
(1, 1, '11etfyrrxqzaf2yqp96sw9hn6ezmg8qtfvjqir590e91qbonez81zbojwmo2i0z5', 'I', 'fdtDddy', '', '', NULL, '', '', '2022-09-06 05:56:52', '2022-09-07 12:04:12'),
(2, 2, 'bzqb3umja5z3g05d5rc17yaxjlmwnolsmrba1oxzv3cwx2ka1sg5pfng4ba2tmbl', 'A', 'fdtsDddy', '', '', NULL, '', '', '2022-09-07 09:26:01', '2022-09-07 09:26:01'),
(3, 3, 'mfbsybvg47a4m7ux4ljdhepr3dn0fod9hh7i6sjok4rnoeozglpxaz3xk2k25xrt', 'A', 'fdtfsDddy', '', '', NULL, '', '', '2022-09-07 10:13:57', '2022-09-07 10:13:57');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_otp_details`
--

CREATE TABLE `tbl_user_otp_details` (
  `id` bigint(20) NOT NULL,
  `code` varchar(6) DEFAULT NULL,
  `email` varchar(32) DEFAULT NULL,
  `phone_number` varchar(16) DEFAULT NULL,
  `otp` varchar(8) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_user_otp_details`
--

INSERT INTO `tbl_user_otp_details` (`id`, `code`, `email`, `phone_number`, `otp`, `is_active`, `created_at`, `updated_at`) VALUES
(3, '+91', NULL, '9998543416', '2985', 1, '2022-09-06 06:29:54', '2022-09-07 09:27:51');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_cuisine`
--
ALTER TABLE `tbl_cuisine`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_dish`
--
ALTER TABLE `tbl_dish`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order_details`
--
ALTER TABLE `tbl_order_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_restaurant_details`
--
ALTER TABLE `tbl_restaurant_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_review`
--
ALTER TABLE `tbl_review`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_time`
--
ALTER TABLE `tbl_time`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user_device`
--
ALTER TABLE `tbl_user_device`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user_otp_details`
--
ALTER TABLE `tbl_user_otp_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_cuisine`
--
ALTER TABLE `tbl_cuisine`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_dish`
--
ALTER TABLE `tbl_dish`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_order_details`
--
ALTER TABLE `tbl_order_details`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_restaurant_details`
--
ALTER TABLE `tbl_restaurant_details`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_review`
--
ALTER TABLE `tbl_review`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_time`
--
ALTER TABLE `tbl_time`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_user_device`
--
ALTER TABLE `tbl_user_device`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_user_otp_details`
--
ALTER TABLE `tbl_user_otp_details`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
