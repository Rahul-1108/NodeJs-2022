var con = require('../../../config/database');
var GLOBALS = require('../../../config/constants');
var common = require('../../../config/common');
var cryptoLib = require('cryptlib');
var asyncLoop = require('node-async-loop');
var moment = require('moment');
var shaKey = cryptoLib.getHashSha256(GLOBALS.KEY, 32);
var emailTemplate = require('../../../config/template');
const { response } = require('express');
const { t } = require('localizify');


var Auth = {


/*=============================================================================================================================
        Check Unique
=============================================================================================================================*/
/* 

check_unique: function (unique_key, callback) {

    var len = Object.keys(unique_key).length;
    var i = 1;

    asyncLoop(unique_key, function (item, next) {
        //console.log(item);
        // Get object key with: item.key 
        // Get associated value with: item.value
        if (item.value != '' && item.value != undefined) {
            var query = con.query("SELECT * FROM tbl_user WHERE role = 'Customer' AND " + item.key + " = ? ", item.value, function (err, result, _fields) {

                if (!err) {
                    if (result[0] == undefined) {
                        if (len == i) {
                            callback(true, t('text_rest_unique_succ'), 1);
                            return;
                        }
                    } else {
                        //console.log(item.key);
                        callback(false, t('text_rest_already_taken', {
                            field: item.key.replace("_", " ")
                        }), 0);
                        return;
                    }
                } else {
                    callback(false, t('text_rest_already_taken', {
                        field: item.key.replace("_", " ")
                    }), 0);
                    return;

                }
                i++;
                next();
            });
        } else {
            i++;
            next();
        }

    }, function () {
        callback();
    });
},
 */


     /**
     * Function to get details of any users
     * 02-09-2022
     * @param {Login User ID} user_id 
     * @param {Function} callback
     */
userdetails: function (user_id, callback) {

        con.query("SELECT u.*,concat('" + GLOBALS.S3_BUCKET_ROOT + GLOBALS.USER_IMAGE + "','',u.profile_image) as profile_image,IFNULL(ut.device_token,'') as device_token,IFNULL(ut.device_type,'') as device_type,IFNULL(ut.token,'') as token FROM tbl_user u LEFT JOIN tbl_user_device as ut ON u.id = ut.user_id WHERE u.id = '" + user_id + "' AND u.is_deleted='0' GROUP BY u.id", function (err, result, fields) {
            console.log("Error of Users", err);
            if (!err && result.length > 0) {
                callback(result[0]);
            } else {
                callback(null);
            }
        });
    },


    /**
     * Function for check unique email and phone numbers for users
     * 02-09-2022
     * @param {Login User ID} user_id 
     * @param {Request Data} request 
     * @param {Function} callback 
     */
checkUniqueFields: function (user_id, request, callback) {

        // Check in database for this email register
        Auth.checkUniqueEmail(user_id, request, function (emailcode, emailmsg, emailUnique) {
            if (emailUnique) {
                Auth.checkUniqueUsername(user_id, request, function (phonecode, phonemsg, phoneUnique) {
                    if (phoneUnique) {
                        callback(phonecode, phonemsg, phoneUnique);
                    } else {
                        callback(phonecode, phonemsg, phoneUnique);
                    }
                });
            } else {
                callback(emailcode, emailmsg, emailUnique);
            }
        });
    },

    /**
     * Function to check email uniqueness
     * 02-09-2022
     * @param {Login User ID} user_id 
     * @param {Request} request 
     * @param {Function} callback 
     */
checkUniqueEmail: function (user_id, request, callback) {

        if (request.email != undefined && request.email != '') {

            if (user_id != undefined && user_id != '') {
                var uniqueEmail = "SELECT * FROM tbl_user WHERE email = '" + request.email + "' AND is_deleted='0' AND id != '" + user_id + "' ";
            } else {
                var uniqueEmail = "SELECT * FROM tbl_user WHERE email = '" + request.email + "' AND is_deleted='0' ";
            }
            con.query(uniqueEmail, function (error, result, fields) {
                if (!error && result[0] != undefined) {
                    callback('0', {
                        keyword: 'rest_keywords_duplicate_email',
                        components: {}
                    }, false);
                } else {
                    callback('1', "Success", true);
                }
            });

        } else {
            callback('1', "Success", true);
        }
    },

    /**
     * Function to check email uniqueness
     * 02-09-2022
     * @param {Login User ID} user_id 
     * @param {Request} request 
     * @param {Function} callback 
     */
checkUniqueUsername: function (user_id, request, callback) {

        if (request.username != undefined && request.username != '') {

            if (user_id != undefined && user_id != '') {
                var uniqueUsername = "SELECT * FROM tbl_user WHERE username = '" + request.username + "' AND is_deleted='0' AND id != '" + user_id + "' ";
            } else {
                var uniqueUsername = "SELECT * FROM tbl_user WHERE username = '" + request.username + "' AND is_deleted='0' ";
            }
            con.query(uniqueUsername, function (error, result, fields) {
                if (!error && result[0] != undefined) {
                    callback('0', {
                        keyword: 'rest_keywords_duplicate_username',
                        components: {}
                    }, false);
                } else {
                    callback('1', "Success", true);
                }
            });

        } else {
            callback('1', "Success", true);
        }
    },

    /**
     * Function to update users details
     * 02-09-2022
     * @param {Login User ID} user_id 
     * @param {Update Parameters} upd_params 
     * @param {Function} callback 
     */
updateCustomer: function (user_id, upd_params, callback) {
        con.query("UPDATE tbl_user SET ? WHERE id = ? ", [upd_params, user_id], function (err, result, fields) {
            if (!err) {
                Auth.userdetails(user_id, function (response, err) {
                    callback(response);
                });
            } else {
                callback(null, err);
            }
        });
    },

    /**
     * Function to signup for users
     * @param {request} request 
     * @param {Function} callback 
     */
signUpUsers: function (request, callback) {
        Auth.checkUniqueFields('', request, function (uniquecode, uniquemsg, isUnique) {
            if (isUnique) {
                
                var customer = {
                    social_id:(request.social_id != undefined && request.social_id != '')?request.social_id:'',
                    name: request.name,
                    email: (request.email != undefined && request.email != "") ? request.email : '',
                    is_active: '1',
                    is_online: '1',
                    profile_image: 'default.png',
                    phone_number: (request.phone_number != undefined && request.phone_number != "") ? request.phone_number : '',
                    password:(request.password != undefined && request.password != '')?cryptoLib.encrypt(request.password,shaKey,process.env.IV):'',
                    login_type: (request.login_type != undefined && request.login_type != "") ? request.login_type : '',
                };

                con.query('INSERT INTO tbl_user SET ?', customer, function (err, result, fields) {
                    if (!err) {
                        
                        common.checkUpdateDeviceInfo(result.insertId, "Customer", request, function () {
                        
                            Auth.userdetails(result.insertId, function (userprofile, err) {
                                
                                common.generateSessionCode(result.insertId, "Customer", function (Token) {
                        
                                    userprofile.token = Token;
                                    callback('1', {
                                        keyword: 'rest_keywords_user_signup_success',
                                        components: {}
                                    }, userprofile);
                                });
                            });
                        });
                    } else {
                        console.log(err)
                        callback('0', {
                            keyword: 'rest_keywords_user_signup_failed',
                            components: {}
                        }, null);
                    }
                });

            } else {
                callback(uniquecode, uniquemsg, null);
            }
        });
    },


               
    /**
     * Function to check login details of users
     * @param {request} request 
     * @param {Function} callback 
     */
checkLogin: function (request, callback) {
  
    
        //chek user details via Email    
        if(request.social_id != undefined && request.login_type  != 'S'){         
            var whereCondition = "social_id = '"+request.social_id+"' AND login_type = '"+request.login_type+"'";
        }else{
        var whereCondition = " email='" + request.email + "' ";
        }
        con.query("SELECT * FROM tbl_user where " + whereCondition + " AND is_deleted='0' ", function (err, result, fields) {

            if (!err ) {

                if(result[0] != undefined){

                console.log(result)

                Auth.userdetails(result[0].id, function (userprofile) {

                    if(request.social_id != undefined && request.login_type != 'S'){
                        var flag = 1;
                    }
                    else{
                    var password = cryptoLib.decrypt(result[0].password, shaKey, GLOBALS.IV);
                    if(password === request.password){
                        var flag = 1;
                    }else{
                        var flag = 0;
                    }
                    }
                   if(flag == 1){
                        var updparams = {
                            is_online: "1",
                            last_login: require('node-datetime').create().format('Y-m-d H:M:S'),
                        }
                        // update device information of user
                        common.checkUpdateDeviceInfo(result[0].id, "Customer", request, function () {
                            Auth.updateCustomer(result[0].id, updparams, function (userprofile, error) {
                                common.generateSessionCode(result[0].id, "Customer", function (token) {
                                    userprofile.token = token;
                                    callback('1', {
                                        keyword: 'rest_keywords_user_login_success',
                                        components: {}
                                    }, userprofile);
                                });
                            });
                        });
                    }else{
                        callback('0', {
                            keyword: 'rest_keywords_inactive_accountby_admin',
                            components: {}
                        }, null);

                    }
                });
            }else{
                if(request.social_id != undefined && request.login_type != 'S'){
                    //chek email exitsts or not 
                    callback('11', {
                        keyword: 'text_user_login_new',
                        components: {}
                    }, null);
                    
                }else{
                    callback('0', {
                        keyword: 'text_user_login_fail',
                        components: {}
                    }, null);
                }

            }
            } else {
                callback('0', {
                    keyword: 'rest_keywords_invalid_email',
                    components: {}
                }, null);
            }
        });
    },

    /**
     * Function to send forgot password links
     * @param {request} request 
     * @param {Function} callback 
     */
forgotPassword: function (request, callback) {

        con.query("SELECT * FROM tbl_user where email='" + request.email + "' AND is_deleted='0' ", function (err, result, fields) {
            if (!err & result[0] != undefined) {

                var updparams = {
                    forgotpassword_token: GLOBALS.APP_NAME + result[0].id,
                    forgotpassword_date: require('node-datetime').create().format('Y-m-d H:M:S')
                }
                Auth.updateCustomer(result[0].id, updparams, function (isupdated) {

                    result[0].encoded_user_id = Buffer.from(result[0].id.toString()).toString('base64');
                    emailTemplate.forgot_password(result[0], function (forgotTemplate) {
                        common.send_email("Forgot Password", request.email, forgotTemplate, function (isSend) {
                            if (isSend) {
                                callback('1', {
                                    keyword: 'rest_keywords_user_forgot_password_success',
                                    components: {}
                                }, result[0]);
                            } else {
                                callback('0', {
                                    keyword: 'rest_keywords_user_forgot_password_failed',
                                    components: {}
                                }, result[0]);
                            }
                        });
                    });
                });
            } else {
                callback('0', {
                    keyword: 'rest_keywords_user_doesnot_exist',
                    components: {}
                }, null);
            }
        });
    },



/*=============================================================================================================================
        Send or Resend OTP
=============================================================================================================================*/

 send_otp: function(req, callback){

     var OTP = Math.floor(1000 + Math.random() * 9000);
    //var OTP = '1234';

     con.query("SELECT * FROM tbl_user_otp_details where  phone_number  = '"+req. phone_number +"' ", function (err, result, fields) {
        console.log(err)

        if(!err && result[0] != undefined){

            con.query('UPDATE tbl_user_otp_details SET ? WHERE id = "'+result[0].id+'" ', {otp: OTP}, function (err, result, fields) {

                //console.log(err)
                req.OTP = OTP;
                callback('1', {
                    keyword: 'rest_keyword_category_succses',
                    components: {}
                }, true);
                //Call The Template for otpp[;'0]
                
               /*  emailTemplate.forgot_password(req,function(msg, code){
                    callback(true, msg, code);
                })
 */
            })
        }
        else {

            var params  = {
                code: req.code,
                phone_number : req. phone_number ,
                otp: OTP
            }
             con.query('INSERT tbl_user_otp_details SET ? ', params, function (err, result, fields) {
                console.log(err)
             req.OTP = OTP;
                
             callback('1', {
                keyword: 'rest_keyword_otp_succses',
                components: {}
            }, true);

                /* emailTemplate.forgot_password(req,function(msg, code){
                    callback(true, msg, code);
                }) */
            })
        }
    });

},

/*=============================================================================================================================
      verify_otp, Send or Resend OTP
=============================================================================================================================*/

verify_otp: function(req, callback){

    con.query("SELECT * FROM tbl_user_otp_details where  phone_number  = '"+req.phone_number+"' AND otp = '"+req.otp+"' ", function (err, result, fields) {

        if(!err && result[0] != undefined){

            var query = con.query("DELETE FROM tbl_user_otp_details WHERE id = '"+result[0].id+"' ", function (err, result, fields) {
            
                callback(true, t('text_customer_otp_verify_succ'),1);
                
            })
        }
        else {
            callback(true, t('text_customer_otp_verify_fail'),0);
        }
    });

},


    //Function to get store category details
restaurentList:function(request,callback){

        var whereCondition = '';

       if(request.location != "undefined" && request.location != "")
       {
          whereCondition = `u.location = '`+request.location+`'`;
       }
  
        var p = `SELECT r.image,r.name,r.avg_rating,r.location,(3959 * 2 * ASIN(SQRT(POWER(SIN((u.latitude - r.latitude) * pi()/180 /2),(2) ) + COS(u.latitude * pi() / 180) * COS(r.latitude * pi()/180) * POWER(SIN((u.longitude - r.longitude) * pi()/180 /2), (2))))) as miles_away 
               FROM tbl_restaurant_details as r
               LEFT JOIN tbl_user as u 
               ON u.id = r.user_id 
               WHERE `+whereCondition+` 
               Having miles_away <= 100`;
               

       con.query(p,function(err,result){
         console.log(result);
        if(!err && result.length > 0){
            console.log("1")
            callback('1',{
                keyword: 'rest_keywords_get_restaurent_success',
                components: {}
            }, result);
        } else {
            console.log("2")
            callback('0',{
                keyword: 'rest_keywords_get_restaurent_FAIL',
                components: {}
            }, null);
        }
    })
    }, 


     
// Time Of Restaurant Function    
    Time:function(request,callback){
        console.log(request)

        var p = "SELECT * FROM tbl_time WHERE id ='" +request+ "'";       
        con.query(p,function(err,result){
            console.log(result)
        if(!err){
            callback("1", {
                keyword: "rest_keywords_get_time_of_restaurant_success",
                components: {},
            },result);
        }
        else{
            callback("0", {
                keyword: "rest_keywords_get_time_of_restaurant_fail",
                components: {},
            },null);
        }
    
        })
    },

      /*
    productList ()
    */
restaurant_details: function (request, callback) {
        whereCondition = " s.id  = '" + request.id  + "' AND";

        var p = `SELECT s.name,s.location,s.image,s.avg_rating,s.total_review,s.about,s.is_open,(3959 * 2 * ASIN(SQRT(POWER(SIN((u.latitude - s.latitude) * pi()/180 /2),(2) ) + COS(u.latitude * pi() / 180) * COS(s.latitude * pi()/180) * POWER(SIN((u.longitude - s.longitude) * pi()/180 /2), (2))))) as miles_away 
        FROM tbl_restaurant_details s
        LEFT JOIN tbl_user u 
        ON u.id=s.user_id where ${whereCondition} s.is_active='1'`;

        con.query(p, function (err, result) {
            //console.log(result)
            if (!err) {
                Auth.cuisine(request.id,function (code, message,quesing_name) {
                    //console.log(request.id)
                    result[0].quesing_name = quesing_name
                    //console.log(quesing_name)

                    callback("1", { 
                        keyword: "rest_keywords_get_store_details_category_success", 
                        components: {}, 
                    }, result);
                })
            }
            else {
                callback("0", { 
                    keyword: "rest_keywords_get_store_details_category_FAIL", 
                    components: {}, 
                }, null);
            }
        })
    },

    /*
    Product category ()
    */
cuisine: function (request,callback) {

        con.query("SELECT * FROM tbl_cuisine WHERE id = '" +request+ "'",
            function (err, result) {
                //console.log("1",result)

                if (!err && result.length > 0) {
                    
                    asyncLoop(result, function (item, next) {
                        
                        Auth.dish(item.id, function (code, message, data) {

                            item.product = data;
                            next();
                        })
                    }, function () {
                        callback("1", { 
                            keyword: "rest_keywords_get_product_Category_success", 
                            components: {}, 
                        }, result);
                    })


                } else {
                    callback("0", { 
                        keyword: "rest_keywords_get_product_Category_Fail", 
                        components: {}, 
                    }, null);
                }
            });
    },

    
dish:function(request,callback){

    var p = "select * from tbl_dish where restaurant_id ="+request+" AND is_active = '1'";       
    con.query(p,function(err,result){
        //console.log(result)
    if(!err){
        callback("1", {
            keyword: "rest_keywords_get_store_details_category_success",
            components: {},
        },result);
    }
    else{
        callback("0", {
            keyword: "rest_keywords_get_store_details_category_FAIL",
            components: {},
        },null);
    }

    })
},



find_restaurant: function (request, callback) {

    var where = '';
 if(request.search_text != undefined && request.search_text !=''){
      where =`AND (r.name LIKE '%`+request.search_text+`%' OR d.name LIKE '%`+request.search_text+`%')`
 }

  var q = con.query(`SELECT r.id,r.name,r.avg_rating,r.location,r.image FROM tbl_restaurant_details r LEFT JOIN tbl_dish d ON r.id = d.restaurant_id where r.is_active ='1' `+where+` group by r.id`, function (err, result) {
     if (!err && result.length > 0) {
        //console.log(result)
         callback('1', {
             keyword: 'rest_keywords_location_search_successfully',
             components: {}
         }, result);
     } else {
        //console.log(err)
         callback('0', {
             keyword: 'rest_keywords_location_such_failed',
             components: {}
         }, null);
     }
 });
},


add_to_cart: function (request, callback) {
      
    var upd_dish = {
       user_id:request.user_id,
       dish_id: request.dish_id,
       total_cart_items: request.total_cart_items,
    };

    Auth.checkDishInfo(request, function (DishInfo, Error) {
        if (DishInfo != null) {
            Auth.updateDishInfo(request, upd_dish, function (result, error) {
                console.log(result)
                Auth.getAddToCartDetails(request, function (result, error) {
               callback("1", {keyword: "rest_keywords_get_store_details_category_success",components: {},},result); 
            });
        });
        } else {
           // upd_dish.user_id = request.user_id;
            Auth.addDishInformation(upd_dish, function (result, error) {
                Auth.getAddToCartDetails(request, function (result, error) {
                callback("1", {keyword: "rest_keywords_get_store_details_category_success",components: {},},result); 
            });
        });
        }
    });
},

checkDishInfo: function (request, callback) {

    con.query("SELECT * FROM  tbl_cart WHERE user_id = '" + request.user_id + "' AND dish_id = '" + request.dish_id + "' ", function (err, result) {
        //console.log(result)
        if (!err && result[0] != undefined) {
            callback(result[0]);
        } else {
            callback(null, err);
        }
    });
},

updateDishInfo: function (request, params, callback) {
    con.query("UPDATE  tbl_cart SET ? WHERE user_id = '" + request.user_id + "' AND dish_id = '" + request.dish_id + "'", params, function (err, result, fields) {
        //console.log(result)
        callback(result);
    });
},

addDishInformation: function (params, callback) {
    con.query('INSERT INTO  tbl_cart SET ?', params, function (err, result, fields) {
        //console.log(result)
        callback(result.insertId);
    });
},


getAddToCartDetails:function(request,callback){

    var p = "select * from tbl_cart where user_id ='"+request.user_id+"' AND dish_id = '" + request.dish_id + "' ";       
    con.query(p,function(err,result){
    if(!err){
        callback(result);
    }
    else{
        callback(null);
    }

    })
},

order: function (request, callback) {
    console.log(request)
    create_a_order(request, function (order_id) {
        //console.log(order_id)
        con.query(`SELECT * FROM tbl_order WHERE id = ${order_id}`, (err, result) => {
            console.log(err)
            if (!err) {
                callback('1', {
                    keyword: 'Order Created...',
                    components: {}
                }, result);
            } else {
                callback('0', {
                    keyword: 'Order not Created...',
                    components: {}
                }, null);
            }

        });
    })

    function create_a_order(request, callback) {
        order = {
            "user_id": request.user_id,
            "restaurant_id": request.restaurant_id,
            "total": request.total,
            "discount_amount": request.discount_amount,
            "service_charge": request.service_charge,
            "sub_total": request.sub_total,
            "grand_total": request.grand_total,
            "status": request.status,
            "payment_method": request.payment_method,
        }
        console.log(order)
        con.query('INSERT INTO tbl_order SET ?', order, (err, result) => {
            console.log(err)
            if (!err) {
                asyncLoop(request.dish, function (item, next) {
            
                    item.user_id = request.user_id
                    console.log(item)
                    item.order_id = result.insertId  
                    //console.log(item)
                    item.sub_total = item.qty * item.price
                    //console.log(item)



                    con.query('INSERT INTO tbl_order_details SET ?', item, () => {
                        next();
                    })
                }, function (err) {
                    //console.log(err);
                });
            } else {
                //console.log(err)
            }
            callback(result.insertId)
        });
    }
}

}
    
module.exports = Auth;
